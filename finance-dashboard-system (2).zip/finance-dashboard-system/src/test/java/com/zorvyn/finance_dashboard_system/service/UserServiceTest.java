package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.UserDto;
import com.zorvyn.finance_dashboard_system.exceptions.UserAlreadyExistsException;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import com.zorvyn.finance_dashboard_system.request.UserRequest;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class UserServiceTest {
    @Mock
    private UserRepository userRepository;
    @InjectMocks
    private UserService userService;

    @Test
    @DisplayName("Should throw exception when creating user with existing email")
    void createUser_EmailExists_ThrowsException() {
        UserRequest dto = UserRequest.builder().emailId("duplicate@test.com").build();
        when(userRepository.existsByEmailId("duplicate@test.com")).thenReturn(true);

        assertThrows(UserAlreadyExistsException.class, () -> userService.addUser(dto));
        verify(userRepository, never()).save(any());
    }
}
