package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.CategorywiseSummaryDto;
import com.zorvyn.finance_dashboard_system.repository.TransactionRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DashboardServiceTest {

    @Mock
    private TransactionRepository transactionRepository;
    @InjectMocks
    private DashboardService dashboardService;

    @Test
    @DisplayName("Case 1: MoM Growth - Should return 50.0% when spending goes from 100 to 150")
    void calculateMoM_ReturnsCorrectPercentage() {
        Long userId = 1L;
        // Mocking Repository to return 150 for Current and 100 for Last month
        when(transactionRepository.sumByUserAndTypeAndDateRange(eq(userId), any(), any(), any()))
                .thenReturn(new BigDecimal("150.00")) // Current Month
                .thenReturn(new BigDecimal("100.00")); // Last Month

        double growth = dashboardService.calculateMonthOverMonthGrowth(userId, LocalDate.now());

        assertEquals(50.0, growth);
    }

    @Test
    @DisplayName("Case 2: Top Category - Should return the category with highest sum")
    void findTopCategory_ReturnsHighestSum() {
        Long userId = 1L;
        CategorywiseSummaryDto top = new CategorywiseSummaryDto("Rent", new BigDecimal("1200"));
        when(transactionRepository.findTopCategory(anyLong(), any(), any()))
                .thenReturn(List.of(top));

        CategorywiseSummaryDto result = dashboardService.topExpenseCategoryDto(userId);

        assertEquals("Rent", result.name());
    }

    @Test
    @DisplayName("Should calculate 100% growth when spending doubles")
    void calculateMoM_DoubledSpending_Returns100Percent() {
        Long userId = 1L;
        // Last Month = 500, Current Month = 1000
        when(transactionRepository.sumByUserAndTypeAndDateRange(eq(userId), any(), any(), any()))
                .thenReturn(new BigDecimal("1000.00")) // Current
                .thenReturn(new BigDecimal("500.00"));  // Last

        double growth = dashboardService.calculateMonthOverMonthGrowth(userId,LocalDate.now());

        assertEquals(100.0, growth);
    }


}
