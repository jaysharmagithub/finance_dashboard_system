package com.zorvyn.finance_dashboard_system.service;
import com.zorvyn.finance_dashboard_system.dto.TransactionDto;
import com.zorvyn.finance_dashboard_system.entity.Category;
import com.zorvyn.finance_dashboard_system.entity.Transaction;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import com.zorvyn.finance_dashboard_system.exceptions.DuplicateTransactionException;
import com.zorvyn.finance_dashboard_system.exceptions.UserNotFoundException;
import com.zorvyn.finance_dashboard_system.repository.CategoryRepository;
import com.zorvyn.finance_dashboard_system.repository.TransactionRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import com.zorvyn.finance_dashboard_system.request.TransactionRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private TransactionService transactionService;

    private TransactionRequest testDto;
    private User testUser;
    private Category testCategory;

    @BeforeEach
    void setUp() {
        testDto = new TransactionRequest(
                new BigDecimal("100.00"),
                "Lunch",
                "req-123", // requestId for idempotency
                "john@example.com",
                TransactionType.EXPENSE,
                "Food"
        );

        testUser = new User();
        testUser.setId(1L);
        testUser.setEmailId("john@example.com");

        testCategory = new Category();
        testCategory.setName("Food");
    }

    @Test
    @DisplayName("Should successfully add a new transaction")
    void addTransaction_Success() {
        // Arrange
        when(transactionRepository.existsByIdempotencyKey("req-123")).thenReturn(false);
        when(userRepository.findByEmailId("john@example.com")).thenReturn(Optional.of(testUser));
        when(categoryRepository.findByName("Food")).thenReturn(Optional.of(testCategory));

        // Act
        assertDoesNotThrow(() -> transactionService.addTransaction(testDto));

        // Assert
        verify(transactionRepository, times(1)).save(any(Transaction.class));
    }

    @Test
    @DisplayName("Should throw exception when Request ID is duplicated (Idempotency)")
    void addTransaction_DuplicateIdempotencyKey() {
        // Arrange
        when(transactionRepository.existsByIdempotencyKey("req-123")).thenReturn(true);

        // Act & Assert
        DuplicateTransactionException exception = assertThrows(DuplicateTransactionException.class,
                () -> transactionService.addTransaction(testDto));

        assertTrue(exception.getMessage().contains("already been processed"));
        verify(transactionRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when User is not found")
    void addTransaction_UserNotFound() {
        // Arrange
        when(transactionRepository.existsByIdempotencyKey(anyString())).thenReturn(false);
        when(userRepository.findByEmailId(anyString())).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(UserNotFoundException.class, () -> transactionService.addTransaction(testDto));
    }

    @Test
    @DisplayName("Should handle Null sums in Net Balance calculation")
    void getNetBalance_HandlesNulls() {
        // Arrange: Mocking the helper calls within getNetBalance
        // Assuming your service calls repository.sumByUserIdAndType
        when(userRepository.findByEmailId("john@example.com")).thenReturn(Optional.of(testUser));
        when(transactionRepository.sumByUserIdAndType(1L, TransactionType.INCOME)).thenReturn(null);
        when(transactionRepository.sumByUserIdAndType(1L, TransactionType.EXPENSE)).thenReturn(new BigDecimal("50.00"));

        // Act
        BigDecimal result = transactionService.getNetBalance("john@example.com");

        // Assert: 0.00 (Income) - 50.00 (Expense) = -50.00
        assertEquals(new BigDecimal("-50.00"), result);
    }

    @Test
    @DisplayName("Case 1: Idempotency - Should block duplicate transaction with same Request ID")
    void addTransaction_DuplicateRequest_ThrowsException() {
        TransactionRequest dto = new TransactionRequest(new BigDecimal("100"), "Lunch", "req-123", "user@test.com", TransactionType.EXPENSE, "Food");

        // Mock the repository to say this ID already exists
        when(transactionRepository.existsByIdempotencyKey("req-123")).thenReturn(true);

        assertThrows(DuplicateTransactionException.class, () -> transactionService.addTransaction(dto));
        verify(transactionRepository, never()).save(any());
    }

    @Test
    @DisplayName("Case 2: Mapping - Should correctly link User and Category entities")
    void addTransaction_Mapping_LinksEntitiesCorrectly() {
        TransactionRequest dto = new TransactionRequest(new BigDecimal("100"), "Lunch", "req-456", "user@test.com", TransactionType.EXPENSE, "Food");
        User user = new User(); user.setId(1L);
        Category category = new Category(); category.setName("Food");

        when(transactionRepository.existsByIdempotencyKey("req-456")).thenReturn(false);
        when(userRepository.findByEmailId("user@test.com")).thenReturn(Optional.of(user));
        when(categoryRepository.findByName("Food")).thenReturn(Optional.of(category));

        transactionService.addTransaction(dto);

        verify(transactionRepository).save(argThat(t ->
                t.getUser().equals(user) && t.getCategory().equals(category)
        ));
    }

    @Test
    @DisplayName("Net Balance should handle null sums gracefully")
    void getNetBalance_NullIncomes_ReturnsNegativeExpenses() {
        String email = "newuser@test.com";
        // Mocking Repository to return NULL (common when no records exist)
        when(transactionRepository.sumByUserIdAndType(anyLong(), eq(TransactionType.INCOME))).thenReturn(null);
        when(transactionRepository.sumByUserIdAndType(anyLong(), eq(TransactionType.EXPENSE))).thenReturn(new BigDecimal("50.00"));

        BigDecimal balance = transactionService.getNetBalance(email);

        assertEquals(new BigDecimal("-50.00"), balance);
    }


}

