package com.zorvyn.finance_dashboard_system.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a specific financial transaction cannot be located.
 *
 * <p><b>Selection Detail:</b>
 * This ensures <b>Data Integrity</b> during update or retrieval operations.
 * By returning a 404 Not Found, the system prevents null-pointer errors
 * and provides clear feedback when a UUID-based identifierName is invalid.</p>
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class TransactionNotFoundException extends RuntimeException {

    /**
     * Constructs a new exception with a descriptive message.
     *
     * @param message Contextual details, such as "Transaction with ID [UUID] not found."
     */
    public TransactionNotFoundException(String message) {
        super(message);
    }
}
