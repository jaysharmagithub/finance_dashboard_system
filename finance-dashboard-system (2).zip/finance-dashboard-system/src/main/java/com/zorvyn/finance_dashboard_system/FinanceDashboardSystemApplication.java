package com.zorvyn.finance_dashboard_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class FinanceDashboardSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanceDashboardSystemApplication.class, args);
	}

}
