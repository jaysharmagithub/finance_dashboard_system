package com.zorvyn.finance_dashboard_system.enums;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * Defines the supported directions for data sorting within paginated API responses.
 * Used across Transaction and User management modules to ensure consistent UI ordering.
 *
 * <p><b>Selection Detail:</b>
 * Acts as a type-safe wrapper for Spring Data {@link org.springframework.data.domain.Sort.Direction},
 * preventing invalid string inputs from reaching the persistence layer.</p>
 */
@Schema(description = "Direction of the sort: ASC for ascending, DESC for descending")
public enum SortingType {

    /**
     * Ascending order (A-Z, 0-9, Oldest-Newest).
     */
    ASC,

    /**
     * Descending order (Z-A, 9-0, Newest-Oldest).
     * Standard default for financial transaction history.
     */
    DESC
}
