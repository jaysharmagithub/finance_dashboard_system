package com.zorvyn.finance_dashboard_system.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a requested financial Category cannot be located in the system.
 *
 * <p><b>Selection Detail:</b>
 * This ensures that the system fails fast during transaction creation if an
 * invalid category name or ID is provided, maintaining strict relational integrity.</p>
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class CategoryNotFoundException extends RuntimeException {

    /**
     * Constructs a new exception with a specific error message.
     *
     * @param message Detailed description of the missing category (e.g., "Category 'Rent' not found").
     */
    public CategoryNotFoundException(String message) {
        super(message);
    }
}

