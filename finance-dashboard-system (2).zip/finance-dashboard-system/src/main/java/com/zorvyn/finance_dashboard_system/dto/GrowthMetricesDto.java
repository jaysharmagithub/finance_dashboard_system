package com.zorvyn.finance_dashboard_system.dto;

import lombok.Builder;

/**
 * Comparative Growth Analytics.
 *
 * Captures the velocity of financial health by comparing current performance
 * against historical benchmarks. Essential for 'Trend Analysis' charts.
 */
@Builder
public record GrowthMetricesDto(
        /* Month-over-Month (MoM) growth percentage.
           Calculated as: ((Current Month - Previous Month) / Previous Month) * 100 */
        double mom,

        /* Year-over-Year (YoY) growth percentage.
           Used to account for seasonal spending patterns and long-term scaling. */
        double yoy
) {
    /**
     * Checks if the growth is trending upwards.
     * Useful for the frontend to quickly decide if it should render
     * a Green (Positive) or Red (Negative) indicator icon.
     */
    public boolean isMoMPositive() {
        return Double.isFinite(mom) && mom > 0;
    }

    /**
     * Safety check for Zero-Division or 'Infinite' growth
     * (Common in new accounts with no prior history).
     */
    public boolean hasHistory() {
        return Double.isFinite(mom) && Double.isFinite(yoy);
    }
}
