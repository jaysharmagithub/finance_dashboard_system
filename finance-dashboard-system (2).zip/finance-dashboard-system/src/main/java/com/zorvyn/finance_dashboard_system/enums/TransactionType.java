package com.zorvyn.finance_dashboard_system.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;

/**
 * Defines the nature of a financial movement within the system.
 * This enum is the core driver for balance calculations and dashboard aggregations.
 *
 * <p><b>Selection Detail:</b>
 * Implements Jackson annotations to allow the API to accept 'income' or 'expense'
 * while maintaining strict Java constants for database queries.</p>
 */
public enum TransactionType {

    /**
     * Represents a financial outflow (e.g., Rent, Food).
     * Subtracted from the Net Balance.
     */
    EXPENSE("expense"),

    /**
     * Represents a financial inflow (e.g., Salary, Gift).
     * Added to the Net Balance.
     */
    INCOME("income");

    private final String value;

    TransactionType(String value) {
        this.value = value.toUpperCase();
    }

    /**
     * Returns the lowercase value for JSON responses.
     * Ensures the API follows modern, user-friendly JSON naming conventions.
     */
    @JsonValue
    public String getValue() {
        return value.toLowerCase();
    }

    /**
     * Maps incoming request strings to TransactionType constants.
     * <b>Selection Detail:</b> Provides a fail-fast mechanism to prevent
     * incorrect financial categorization.
     *
     * @param input The raw string from the JSON payload.
     * @return The matching {@link TransactionType}.
     * @throws IllegalArgumentException if the input is not 'income' or 'expense'.
     */
    @JsonCreator
    public static TransactionType from(String input) {
        return Arrays.stream(values())
                .filter(t -> t.value.equalsIgnoreCase(input))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid transaction type: " + input));
    }
}
