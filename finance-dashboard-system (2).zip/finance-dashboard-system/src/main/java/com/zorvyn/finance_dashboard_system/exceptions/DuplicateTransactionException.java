package com.zorvyn.finance_dashboard_system.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a transaction request is identified as a duplicate.
 *
 * <p><b>Selection Detail:</b>
 * This is the cornerstone of the system's <b>Idempotency Logic</b>. It prevents
 * "Double-Spending" by intercepting requests with a RequestID that has already
 * been successfully processed into the database.</p>
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateTransactionException extends RuntimeException {

    /**
     * Constructs the exception with a descriptive message.
     *
     * @param message Detailed error context, typically including the duplicate RequestID.
     */
    public DuplicateTransactionException(String message) {
        super(message);
    }
}
