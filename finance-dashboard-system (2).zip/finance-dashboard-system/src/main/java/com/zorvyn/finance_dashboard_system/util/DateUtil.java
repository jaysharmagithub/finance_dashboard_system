package com.zorvyn.finance_dashboard_system.util;

import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

/**
 * Utility class for standardized financial date range calculations.
 * Centralizes logic for Time-Series analytics (MoM and YoY growth).
 *
 * <p><b>Selection Detail:</b>
 * Implements a private constructor to prevent instantiation (Utility Pattern)
 * and utilizes 'stateless' method calls to prevent 'Clock Drift' bugs common
 * in long-running server environments.</p>
 */
public final class DateUtil {

    /**
     * Prevents instantiation of this utility class.
     */
    private DateUtil() {
        throw new UnsupportedOperationException("Utility class should not be instantiated");
    }

    /**
     * Calculates the start date of the current calendar year (January 1st).
     * Used for Year-to-Date (YTD) expense and income summations.
     *
     * @return {@link LocalDate} representing Jan 1 of the current year.
     */
    public static LocalDate getStartOfCurrentYear() {
        return LocalDate.now().withDayOfYear(1);
    }

    /**
     * Calculates the start date of the previous calendar year.
     * Essential for Year-over-Year (YoY) growth baseline calculations.
     */
    public static LocalDate getStartOfLastYear() {
        return LocalDate.now().minusYears(1).withDayOfYear(1);
    }

    /**
     * Calculates the final day of the previous calendar year (December 31st).
     */
    public static LocalDate getEndOfLastYear() {
        return LocalDate.now().minusYears(1).with(TemporalAdjusters.lastDayOfYear());
    }

    /**
     * Calculates the first day of the current month.
     * Used as the anchor for Month-to-Date (MTD) dashboard metrics.
     */
    public static LocalDate getStartOfCurrentMonth() {
        return LocalDate.now().withDayOfMonth(1);
    }

    /**
     * Calculates the start date of the preceding month.
     * Used as the baseline for Month-over-Month (MoM) trend analysis.
     */
    public static LocalDate getStartOfLastMonth() {
        return LocalDate.now().minusMonths(1).withDayOfMonth(1);
    }

    /**
     * Calculates the final day of the preceding month.
     */
    public static LocalDate getEndOfLastMonth() {
        return LocalDate.now().minusMonths(1).with(TemporalAdjusters.lastDayOfMonth());
    }
}
