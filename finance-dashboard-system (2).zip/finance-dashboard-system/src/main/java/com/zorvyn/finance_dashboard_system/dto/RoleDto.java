package com.zorvyn.finance_dashboard_system.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Builder;

/**
 * Data Transfer Object for User Roles.
 *
 * Role names are strictly validated to ensure they follow our system's
 * naming conventions (typically uppercase, e.g., 'ROLE_ADMIN').
 */
@Builder
public record RoleDto(
        /* Ensuring name is not just non-null, but contains actual characters.
           In production, roles are the backbone of our 'EnableMethodSecurity'. */
        @NotNull(message = "Role name cannot be null.")
        @NotBlank(message = "Role name cannot be empty or whitespace.")
        @Size(min = 3, max = 20, message = "Role name must be between 3 and 20 characters.")
        @Pattern(
                regexp = "^ROLE_[A-Z]+$",
                message = "Role name must start with 'ROLE_' and contain only uppercase letters."
        )
        String name
) {

    /**
     * Helper to ensure the role name is always stored/processed in a
     * consistent format, regardless of how the frontend sends it.
     */
    public String canonicalName() {
        return name != null ? name.trim().toUpperCase() : null;
    }
}
