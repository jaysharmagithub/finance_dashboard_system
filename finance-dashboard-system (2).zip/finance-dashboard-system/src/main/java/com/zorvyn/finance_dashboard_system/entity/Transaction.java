package com.zorvyn.finance_dashboard_system.entity;

import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
/**
 * Entity representing a financial transaction within the system.
 * This class tracks income and expenses, linked to specific users and categories.
 *
 * <p>Key features include:
 * <ul>
 *   <li>Idempotency support via a unique Request ID to prevent duplicate processing.</li>
 *   <li>Relational mapping to {@link User} and {@link Category} entities.</li>
 *   <li>Precision handling using {@link BigDecimal} for financial amounts.</li>
 * </ul>
 */
@Builder
@Table(name = "transactions", indexes = {
        @Index(name = "idx_transaction_user", columnList = "user_id"),
        @Index(name = "idx_transaction_date", columnList = "created_at"),
        @Index(name = "idx_user_date_type", columnList = "user_id, created_at, type")

})
@Entity
@Getter
@Setter
@AttributeOverride(name = "id", column = @Column(name = "transaction_id"))
@NoArgsConstructor
@AllArgsConstructor
public class Transaction extends BaseUseCase{

    /**
     * Unique business identifier for the transaction (UUID string).
     * Used for external references instead of exposing internal database IDs.
     */
    @Column(unique = true, nullable = false)
    private String identifierName;


    /**
     * The monetary value of the transaction.
     * Stored as BigDecimal to maintain high precision for currency.
     */
    @Column(nullable = false,precision = 19, scale = 4)
    private BigDecimal amount;

    /**
     * A brief description or note regarding the transaction.
     */
    @Column(length = 500)
    private String description;


    /**
     * Defines whether the transaction is an INCOME or an EXPENSE.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType type;

    /**
     * The user who owns this transaction.
     * Establishes a Many-to-One relationship with the User entity.
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id",nullable = false)
    private User user;

    /**
     * Client-provided unique key to ensure idempotency.
     * Prevents the same transaction from being recorded twice if a request is retried.
     */
    @Column(unique = true, nullable = false)
    private String idempotencyKey;

    /**
     * The category (e.g., Food, Salary) this transaction belongs to.
     */
    @ManyToOne(fetch = FetchType.EAGER) // Required by @SoftDelete
    @Fetch(FetchMode.JOIN)             // Forces a single JOIN query
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;
}
