package com.zorvyn.finance_dashboard_system.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Arrays;

/**
 * Defines the classification of user permissions within the system.
 * Acts as the blueprint for Role-Based Access Control (RBAC) tiers.
 *
 * <p><b>Selection Detail:</b>
 * Implements Jackson annotations for seamless JSON serialization/deserialization,
 * allowing the frontend to interact with lowercase strings while the backend
 * enforces uppercase business constants.</p>
 */
public enum RoleType {

    /**
     * Read-only access to dashboard metrics and transaction history.
     */
    USER("user"),

    /**
     * Access to read-only data plus advanced analytical insights and reports.
     */
    ANALYST("analyst"),

    /**
     * Full administrative control, including user management and system audits.
     */
    ADMIN("admin");

    private final String value;

    RoleType(String value) {
        this.value = value.toUpperCase();
    }

    /**
     * Returns the string representation for JSON responses.
     * <b>Selection Detail:</b> Ensures consistent lowercase/uppercase API contracts.
     */
    @JsonValue
    public String getValue() {
        return value;
    }

    /**
     * Factory method for mapping incoming request strings to enum constants.
     * <b>Selection Detail:</b> Provides a fail-fast mechanism for invalid role inputs.
     *
     * @param input The raw string from the API request.
     * @return The matching {@link RoleType}.
     * @throws IllegalArgumentException if the input does not match a defined role.
     */
    @JsonCreator
    public static RoleType from(String input) {
        return Arrays.stream(values())
                .filter(t -> t.value.equalsIgnoreCase(input))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid role: " + input));
    }
}
