package com.zorvyn.finance_dashboard_system.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Configuration for the Data Access Object (DAO) Authentication Provider.
 * This class orchestrates the verification of user credentials against the database.
 *
 * <p><b>Selection Detail:</b>
 * By explicitly defining the {@link DaoAuthenticationProvider}, the system
 * bridges the {@link UserDetailsService} and {@link PasswordEncoder}, ensuring
 * that the 'Authentication Handshake' is performed with BCrypt precision.</p>
 */
@Configuration
public class DaoConfig {

    private final UserDetailsService userDetailsService;

    /**
     * Constructor injection ensures the required UserDetailsService is available
     * before the bean is initialized.
     */
    public DaoConfig(UserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    /**
     * Defines the primary strategy for database-backed authentication.
     *
     * @param passwordEncoder The BCrypt bean used to verify incoming credentials.
     * @return A fully configured {@link DaoAuthenticationProvider}.
     */
    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider(PasswordEncoder passwordEncoder) {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();

        // Linking the custom DB lookup logic
        provider.setUserDetailsService(userDetailsService);

        // Linking the secure hashing algorithm
        provider.setPasswordEncoder(passwordEncoder);

        return provider;
    }
}
