package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.TransactionDto;
import com.zorvyn.finance_dashboard_system.request.TransactionRequest;
import org.springframework.data.domain.Page;

import java.math.BigDecimal;

public interface ITransactionService {
    void addTransaction(TransactionRequest transactionDto);
    void updateTransaction(String identifier,TransactionRequest transactionDto);
    BigDecimal getTotalIncome(String username);
    BigDecimal getTotalExpenses(String username);
    BigDecimal getNetBalance(String username);
    Page<TransactionDto> getTranscations(int pageNo, int pageSize, String sortByField, String sortDirection);
//    Page<TransactionDto> getLatestWeeklyTranscation(String username);
    TransactionDto getTranscation(String username,String identifier);
    Page<TransactionDto> getUserTransactions(String username,
                                             int pageNo, int pageSize,
                                             String sortByField,
                                             String sortDirection);
}
