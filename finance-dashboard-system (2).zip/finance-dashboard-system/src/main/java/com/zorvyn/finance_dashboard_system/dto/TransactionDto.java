package com.zorvyn.finance_dashboard_system.dto;


import com.zorvyn.finance_dashboard_system.entity.Role;
import com.zorvyn.finance_dashboard_system.entity.Transaction;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.enums.RoleType;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import jakarta.validation.constraints.*;
import lombok.Builder;


import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;
/**
 * Data Transfer Object for Financial Transactions.
 *
 * This record handles incoming transaction requests. It includes strict
 * validation for monetary values and an idempotency key (requestId)
 * to prevent duplicate processing of the same transaction.
 */
@Builder
public record TransactionDto(
         /* Validates the amount stays within
       business limits (1.00 to 999,999.00). */
        @NotNull(message = NO_NULL_AMOUNT_ACCEPTABLE)
        @Digits(integer = 6,
                fraction = 2,
                message = AMOUNT_IS_ALLOWED_UP_TO_6_DIGITS_AND_2_DECIMAL_PLACES
        )
        @DecimalMin(value = "1.00",
                message = THE_1_00_MUST_BE_THERE
        )
        @DecimalMax(value = "999999.00",
                message = THE_MAXIMUM_ALLOWED_LIMIT_999999_00_EXCEEDED
        )
        BigDecimal amount,

        @NotNull(message = NO_NULL_DESCRIPTION_ACCEPTABLE)
        @Size(max = 255,
                message = DESCRIPTION_IS_ALLOWED_UP_TO_UP_TO_255_CHARACTERS
        )
        @Pattern(regexp = A_Z_A_Z_0_9_$,
                message = DESCRIPTION_CONTAINS_INVALID_CHARACTERS
        )
        String description,

        @NotBlank(message = "Email is required")
        @Email(
                regexp = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$",
                message = "Please provide a valid corporate or personal email address"
        )
        String username,
        @NotNull(message = INVALID_TYPE_OF_TRANSACTION)
        TransactionType type,

        @NotBlank(message = CATEGORY_IS_REQUIRED)
        @Size(max = 50, message = CATEGORY_IS_ALLOWED_UP_TO_50_CHARACTERS)
        @Pattern(regexp = A_Z_A_Z_$,
                message = CATEGORY_MUST_CONTAIN_ONLY_LETTERS_AND_SPACES)
        String category)
{
    public static final String NO_NULL_AMOUNT_ACCEPTABLE = "No null amount acceptable";
    public static final String AMOUNT_IS_ALLOWED_UP_TO_6_DIGITS_AND_2_DECIMAL_PLACES = "Amount is allowed up to 6 digits and 2 decimal places";
    public static final String THE_1_00_MUST_BE_THERE = "The 1.00 must be there";
    public static final String THE_MAXIMUM_ALLOWED_LIMIT_999999_00_EXCEEDED = "The maximum allowed limit 999999.00 exceeded";
    public static final String NO_NULL_DESCRIPTION_ACCEPTABLE = "No null description acceptable";
    public static final String DESCRIPTION_IS_ALLOWED_UP_TO_UP_TO_255_CHARACTERS = "Description is allowed up to up to 255 characters";
    public static final String DESCRIPTION_CONTAINS_INVALID_CHARACTERS = "Description contains invalid characters";
    public static final String A_Z_A_Z_0_9_$ = "^[a-zA-Z0-9 .,\\-()]+$";
    public static final String CATEGORY_MUST_CONTAIN_ONLY_LETTERS_AND_SPACES = "Category must contain only letters and spaces";
    public static final String CATEGORY_IS_REQUIRED = "Category is required";
    public static final String CATEGORY_IS_ALLOWED_UP_TO_50_CHARACTERS = "Category is allowed up to 50 characters";
    public static final String A_Z_A_Z_$ = "^[a-zA-Z ]+$";
    public static final String USERNAME_NAME_CAN_NOT_BLANK = "Username name can not blank";
    public static final String USERNAME_CAN_ONLY_CONTAIN_LETTERS_NUMBERS_AND_UNDERSCORES = "Username can only contain letters, numbers, and underscores";
    public static final String A_Z_A_Z_0_9_$1 = "^[a-zA-Z0-9_@]+$";
    public static final String INVALID_TYPE_OF_TRANSACTION = "Invalid type of transaction";


    /**
     * Converts Entity to DTO for API responses.
     * Ensures nested entity data (User email and Category name) is flattened.
     */
    public static TransactionDto toDto(Transaction transaction) {
        if (transaction == null)
            throw new IllegalArgumentException("the transaction is not null");;
        return TransactionDto
                .builder()
                .category(transaction.getCategory().getName())
                .description(transaction.getDescription())
                .amount(transaction.getAmount())
                .username(transaction.getUser().getEmailId())
                .type(transaction.getType())
                .build();
    }
}
