package com.zorvyn.finance_dashboard_system.controller;

import com.zorvyn.finance_dashboard_system.response.ErrorResponse;
import com.zorvyn.finance_dashboard_system.response.SuccessResponse;
import com.zorvyn.finance_dashboard_system.security.LoginRequest;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * Entry point for User Authentication.
 *
 * Manages the "Handshake" between the user's credentials and our Security Provider.
 * This implementation relies on Session-based security via the SecurityContextRepository.
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthenticationController {

    private final AuthenticationManager authenticationManager;
    private final SecurityContextRepository securityContextRepository;

    @PostMapping("/login") // Added explicit mapping for clarity
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest,
                                   HttpServletRequest request,
                                   HttpServletResponse response) {

        log.debug("Login attempt started for user: {}", loginRequest.email());

        try {
            // Verify Credentials
            // The AuthenticationManager will look up the user and check the password hash.
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.email(), loginRequest.password())
            );

            // Establish a Secure Session Context
            SecurityContext context = SecurityContextHolder.createEmptyContext();
            context.setAuthentication(authentication);
            SecurityContextHolder.setContext(context);

            // Persist the Session
            // This ensures the JSESSIONID cookie is linked to the authenticated state.
            securityContextRepository.saveContext(context, request, response);

            log.info("Successfully authenticated user: [{}]. Session created.", loginRequest.email());

            // Returning a JSON Map is better for frontends than a plain string.
            return ResponseEntity.ok(
                    SuccessResponse
                            .builder()
                            .data(authentication.getName())
                            .message("Login successful")
                            .status(HttpStatus.OK.value())
                            .timeStamp(Instant.now().toString())
                            .path(request.getRequestURI()).build());

        } catch (AuthenticationException ex) {
            // Log as a warning for security monitoring (Audit trail)
            log.warn("Failed login attempt for user: [{}] - Reason: {}",
                    loginRequest.email(), ex.getMessage());

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(
                            ErrorResponse.builder()
                            .timestamp(LocalDateTime.now())
                            .message("The email or password provided is incorrect.")
                            .status(HttpStatus.UNAUTHORIZED.value())
                            .error(HttpStatus.UNAUTHORIZED.getReasonPhrase()).build()
                    );
        }
    }
}
