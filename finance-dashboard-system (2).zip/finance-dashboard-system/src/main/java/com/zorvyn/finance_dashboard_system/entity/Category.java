package com.zorvyn.finance_dashboard_system.entity;

import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@NoArgsConstructor
@Setter
@AttributeOverride(name = "id", column = @Column(name = "category_id"))
public class Category extends BaseUseCase {

    @Column(nullable = false,unique = true)
    private String name;

    // In Category.java
    @OneToMany(mappedBy = "category") // Non-owning side
    private List<Transaction> transactions = new ArrayList<>();

    public Category(String salary) {
        this.name = salary;
    }


    public void addTransaction(Transaction transaction){
        this.transactions.add(transaction);
        transaction.setCategory(this);
    }

}
