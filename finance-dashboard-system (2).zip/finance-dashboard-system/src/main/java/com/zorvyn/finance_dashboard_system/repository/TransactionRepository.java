package com.zorvyn.finance_dashboard_system.repository;

import com.zorvyn.finance_dashboard_system.dto.CategorywiseSummaryDto;
import com.zorvyn.finance_dashboard_system.entity.Transaction;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


/**
 * Repository interface for {@link Transaction} entity.
 * Handles specialized financial aggregations and user-specific data retrieval.
 *
 * <p>Optimizations included:
 * <ul>
 *   <li>JPQL Constructor Expressions for direct DTO mapping.</li>
 *   <li>Null-safe aggregations using COALESCE.</li>
 *   <li>Indexed lookups for User and Date ranges.</li>
 * </ul>
 */

@Repository
public interface TransactionRepository extends JpaRepository<Transaction,Long> {
//    List<Amount> findByUserId(Long id);

    /**
     * Calculates the total sum of transactions for a specific user and type.
     * Uses COALESCE to ensure a return value of 0.00 even if no records exist.
     *
     * @param userId The unique ID of the user.
     * @param type   The {@link TransactionType} (INCOME/EXPENSE).
     * @return The aggregated total as a {@link BigDecimal}.
     */
    @Query("""
            SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.user.id = :userId AND t.type = :type
                """ )
    BigDecimal sumByUserIdAndType(@Param("userId") Long userId, @Param("type") TransactionType type);

    /**
     * Calculates the total sum for a user within a specific date range.
     * Used for calculating Year-to-Date (YTD) and Month-over-Month (MoM) growth.
     *
     * @param userId    The unique ID of the user.
     * @param type      The transaction type (INCOME/EXPENSE).
     * @param startDate Start of the period (inclusive).
     * @param endDate   End of the period (inclusive).
     * @return The aggregated total for the time period.
     */
    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t " +
            "WHERE t.user.id = :userId AND t.type = :type " +
            "AND t.createdAt >= :startDate AND t.createdAt <= :endDate")
    BigDecimal sumByUserAndTypeAndDateRange(@Param("userId")Long userId,@Param("type") TransactionType type,
                                         @Param("startDate") LocalDate startDate,@Param("endDate") LocalDate endDate);

    /**
     * Retrieves a paginated list of transactions belonging specifically to one user.
     * This method enforces 'User Data Isolation' at the database level, ensuring
     * that users can only access their own financial records.
     *
     * @param userId   The unique ID of the authenticated user.
     * @param pageable Pagination and sorting information (e.g., page number, size, sort).
     * @return A {@link Page} of {@link Transaction} entities for the specific user.
     */
    @Query("SELECT t FROM Transaction t WHERE t.user.id = :userId")
    Page<Transaction> findTransactionByUserId(@Param("userId") Long userId, Pageable pageable);


    /**
     * Finds a specific transaction using userid.
     * This is used to retrieve or update a record without exposing the
     * auto-incremented primary key to the client.
     *
     * @param userId The id of the user who make a transaction.
     * @return An {@link Optional} containing the transaction if found.
     */
    @Query("SELECT t FROM Transaction t WHERE t.user.emailId =:userId AND t.identifierName =:identifier")
    Optional<Transaction> findByUserEmailId(@Param("userId") String emailId,@Param("") String identifier);

    /**
     * Finds a specific transaction using its public UUID-based identifier.
     * This is used to retrieve or update a record without exposing the
     * auto-incremented primary key to the client.
     *
     * @param identifier The UUID string (identifierName) of the transaction.
     * @return An {@link Optional} containing the transaction if found.
     */

    @Query("SELECT t FROM Transaction t where t.identifierName =:identifier")
    Optional<Transaction> findByIdentifierName(@Param("identifier") String identifier);


    /**
     * Aggregates transaction totals grouped by category for a specific user.
     * Maps results directly into {@link CategorywiseSummaryDto} using a constructor expression.
     *
     * @param userId The unique ID of the user.
     * @param type   The transaction type to filter (usually EXPENSE).
     * @return A list of category names and their corresponding totals.
     */
    @Query("""
            SELECT new com.zorvyn.finance_dashboard_system.dto.CategorywiseSummaryDto(t.category.name,SUM(t.amount)) 
                        FROM Transaction t  WHERE t.user.id =:userId AND t.type =:type
                                    GROUP BY t.category.name
                        """)
    List<CategorywiseSummaryDto> findCategoryTotalsByUserIdAndType(@Param("userId") Long userId,
                                                                   @Param("type") TransactionType type);

    /**
     * Retrieves the top-spending category using pagination to simulate a 'LIMIT 1' behavior.
     *
     * @param userId   The unique ID of the user.
     * @param type     The transaction type.
     * @param pageable Used to restrict the result set (e.g., PageRequest.of(0, 1)).
     * @return A list containing the single highest-spending category DTO.
     */
    @Query("""
            SELECT new com.zorvyn.finance_dashboard_system.dto.CategorywiseSummaryDto(t.category.name,SUM(t.amount)) 
                        FROM Transaction t  WHERE t.user.id =:userId AND t.type =:type GROUP BY t.category.name ORDER BY
                                     Sum(t.amount) DESC 
                        """)
    List<CategorywiseSummaryDto> findTopCategory(@Param("userId") Long userId,
                                                                   @Param("type") TransactionType type,
                                                 Pageable pageable);
//    @Query("SELECT t FROM Transaction t WHERE t.user.id = :userId")
//    Page<Transaction> findByUserId(@Param("userId") Long userId, Pageable pageable);

    /**
     * Checks if a transaction with the given idempotency key already exists.
     * Essential for preventing duplicate processing of the same request.
     *
     * @param idempotencyKey Client-provided unique request identifier.
     * @return true if the key exists, false otherwise.
     */
    boolean existsByIdempotencyKey(String idempotencyKey);
}
