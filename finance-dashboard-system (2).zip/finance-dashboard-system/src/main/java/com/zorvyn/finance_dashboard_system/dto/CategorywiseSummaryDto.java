package com.zorvyn.finance_dashboard_system.dto;

import lombok.Builder;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * Aggregated Spend by Category.
 *
 * Primarily used for 'Spending Breakdown' visualizations.
 * Maps a human-readable category name to its cumulative monetary value.
 */
@Builder
public record CategorywiseSummaryDto(
        /* The unique display name of the category (e.g., 'Groceries', 'Rent'). */
        String name,

        /* Cumulative sum of transactions within this category.
           Using BigDecimal to maintain cent-perfect accuracy for financial reports. */
        BigDecimal total
) {
    /**
     * Compact Constructor for Data Integrity.
     * Ensures we never send a 'null' category name or negative totals to the UI.
     */
    public CategorywiseSummaryDto {
        name = (name == null || name.isBlank()) ? "Uncategorized" : name.trim();
        total = (total == null) ? BigDecimal.ZERO : total;
    }

    /**
     * Helper to determine if this category represents a significant portion of spending.
     * Useful for the UI to highlight 'Big Spender' categories.
     */
    public boolean hasSpending() {
        return total.compareTo(BigDecimal.ZERO) > 0;
    }
}
