package com.zorvyn.finance_dashboard_system.entity;

import com.zorvyn.finance_dashboard_system.exceptions.InvalidRoleAssignmentException;
import jakarta.persistence.*;
import lombok.*;

import javax.management.OperationsException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
/**
 * Entity representing a system security authority (e.g., ROLE_ADMIN, ROLE_USER).
 * This class acts as the blueprint for Role-Based Access Control (RBAC).
 *
 * <p><b>Selection Detail:</b>
 * Implements Domain-Driven helper methods to ensure bidirectional consistency
 * between Users and Roles, preventing "Partial States" in the security context.</p>
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@AttributeOverride(name="id", column = @Column(name = "role_id"))
public class Role extends BaseUseCase {

    /**
     * The unique name of the security role.
     * <b>Standard:</b> Should follow the 'ROLE_' prefix convention for Spring Security.
     */
    @Column(nullable = false, unique = true)
    private String name;

    /**
     * The set of users currently associated with this security authority.
     * Mapped via the 'roles' collection in the {@link User} entity.
     */
    @ManyToMany(mappedBy = "roles", fetch = FetchType.LAZY)
    private Set<User> users = new HashSet<>();

    public Role(String role) {
        this.name = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Role)) return false;
        return id != null && id.equals(((Role) o).id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }

    /**
     * Synchronizes a role assignment between the Role and User entities.
     * <p><b>Selection Detail:</b> Enforces data integrity by checking for
     * existing assignments and handling null-safety for the User's role set.</p>
     *
     * @param user The target user for the role assignment.
     * @throws InvalidRoleAssignmentException if the user already possesses this role.
     */
    public void assignRoleToUser(User user){
        if(user == null) throw new IllegalArgumentException("the user is null");
        if(user.getRoles() != null && user.getRoles().contains(this)) throw new InvalidRoleAssignmentException("the role is already assigned");
        if(user.getRoles() != null)  user.getRoles().add(this);
        else user.setRoles(new HashSet<>(Set.of(this)));
        this.users.add(user);
    }

    /**
     * Revokes the current role from a user.
     * Ensures bidirectional removal from both the Role's user set and the User's role set.
     */
    public void removeRoleFromUser(User user){
        if(user == null) throw new IllegalArgumentException("the user is null");
        user.getRoles().remove(this);
        this.users.remove(user);
    }

    /**
     * Bulk revocation helper for administrative cleanup.
     */
    public void removeRolesFromUser(List<User> inputUsers){
        if(users == null) throw new IllegalArgumentException("the user is null");
        inputUsers.forEach(this::removeRoleFromUser);
    }

    /**
     * Bulk assignment helper to process multiple users in a single operation.
     */
    public void assignRolesToUser(List<User> users){
        if(users == null) throw new IllegalArgumentException("the user is null");
        users.forEach(this::assignRoleToUser);
    }

}
