package com.zorvyn.finance_dashboard_system.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;

/**
 * Central configuration for Security-related beans.
 * Defines the core infrastructure for authentication, password hashing, and session management.
 *
 * <p><b>Selection Detail:</b>
 * Implements standard Bcrypt encoding for credential safety and configures
 * a persistent SecurityContextRepository to maintain user state across sessions.</p>
 */
@Configuration
public class BeanConfig {

    /**
     * Exposes the AuthenticationManager to the application context.
     * Required for manual authentication triggers in custom login controllers.
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    /**
     * Defines the primary password encoding strategy for the system.
     * <p><b>Security Detail:</b> Uses <b>BCrypt</b> (Industry Standard) to provide
     * computationally expensive hashing, protecting against brute-force attacks.</p>
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Configures the repository for storing the SecurityContext between requests.
     * Uses the HTTP Session to persist user identity after a successful login.
     */
    @Bean
    public SecurityContextRepository securityContextRepository() {
        return new HttpSessionSecurityContextRepository();
    }
}
