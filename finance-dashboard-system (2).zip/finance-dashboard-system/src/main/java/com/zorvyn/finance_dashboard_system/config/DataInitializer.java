package com.zorvyn.finance_dashboard_system.config;

import com.zorvyn.finance_dashboard_system.entity.*;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import com.zorvyn.finance_dashboard_system.exceptions.CategoryNotFoundException;
import com.zorvyn.finance_dashboard_system.exceptions.UserNotFoundException;
import com.zorvyn.finance_dashboard_system.repository.*;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final CategoryRepository categoryRepository;
    private final TransactionRepository transactionRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void run(String... args) {
//        if (userRepository.count() > 0) return; // Prevent duplicate data

        // 1. Create Roles
//        Role adminRole = roleRepository.save(new Role("ROLE_ADMIN"));
        Role userRole = roleRepository.findByName("ROLE_USER").orElseGet(() -> new Role("ROLE_USER"));
//        Role viewerRole = roleRepository.save(new Role("ROLE_VIEWER"));

        // 2. Create Categories
        Category salary = categoryRepository.findByName("Salary").orElseThrow(() -> new CategoryNotFoundException("not found"));
        Category freelance = categoryRepository.findByName("Freelance").orElseThrow(() -> new CategoryNotFoundException("not found"));;
        Category rent = categoryRepository.findByName("Rent").orElseThrow(() -> new CategoryNotFoundException("not found"));;
        Category food = categoryRepository.findByName("Food").orElseThrow(() -> new CategoryNotFoundException("not found"));;
        Category travel = categoryRepository.findByName("Travel").orElseThrow(() -> new CategoryNotFoundException("not found"));;
        Category utilities = categoryRepository.findByName("Utilities").orElseThrow(() -> new CategoryNotFoundException("not found"));;

        //3. Create Users
//        User admin = User.builder()
//                .firstName("Admin").lastName("User").emailId("admin@finance.com")
//                .password(passwordEncoder.encode("admin123")).mobileNo("9999999999")
//                .roles(Set.of(adminRole)).build();

        User testUser = userRepository.findByEmailId("john@example.com").orElseThrow(() -> new UserNotFoundException("not found"));
//                .password(passwordEncoder.encode("password123")).mobileNo("9876543210")
//                .roles(Set.of(userRole)).build();

        User rahul = User.builder()
                .firstName("Rahul").lastName("Sharma").emailId("rahulsharma@gmail.com")
                .password(passwordEncoder.encode("password123")).mobileNo("9876543218")
                .roles(Set.of(userRole)).build();

        User ranjit = User.builder()
                .firstName("Ranjit").lastName("Shinde").emailId("ranjit@gmail.com")
                .password(passwordEncoder.encode("password123")).mobileNo("9876543120")
                .roles(Set.of(userRole)).build();
        User prafull = User.builder()
                .firstName("Prafull").lastName("K").emailId("prafull@gmail.com")
                .password(passwordEncoder.encode("password123")).mobileNo("9876534210")
                .roles(Set.of(userRole)).build();
        User rekha = User.builder()
                .firstName("Rekha").lastName("S").emailId("rekha@gmail.com")
                .password(passwordEncoder.encode("password123")).mobileNo("9875643210")
                .roles(Set.of(userRole)).build();

        User rakesh = User.builder()
                .firstName("Rakesh").lastName("S").emailId("rakesh@gmail.com")
                .password(passwordEncoder.encode("password123")).mobileNo("9786543210")
                .roles(Set.of(userRole)).build();

//        userRepository.saveAll(List.of(testUser,admin,rakesh, rekha, prafull, ranjit, rahul));
//        userRepository.save(testUser);


        // 4. Create 20+ Transactions for John Doe (Current & Previous Months/Years)
        LocalDate now = LocalDate.now();
        List<Transaction> transactions = new ArrayList<>();

        // --- INCOME ---
        transactions.add(createTx(testUser, salary, "Monthly Salary", 5000, now, TransactionType.INCOME));
        transactions.add(createTx(testUser, salary, "Previous Month Salary", 5000, now.minusMonths(1), TransactionType.INCOME));
        transactions.add(createTx(testUser, freelance, "Project Bonus", 1200, now.minusDays(5), TransactionType.INCOME));
        transactions.add(createTx(testUser, salary, "Last Year Bonus", 3000, now.minusYears(1).withMonth(12), TransactionType.INCOME));

        // --- EXPENSES: CURRENT MONTH ---
        transactions.add(createTx(testUser, rent, "Monthly Rent", 1500, now.withDayOfMonth(1), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Grocery Shopping", 150, now.minusDays(2), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, travel, "Uber Ride", 45, now.minusDays(1), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, utilities, "Electricity Bill", 120, now.minusDays(10), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Dinner Out", 80, now.minusDays(3), TransactionType.EXPENSE));

        // --- EXPENSES: LAST MONTH (For MoM Growth testing) ---
        // Setting last month higher to test "Negative Growth" or lower for "Positive Growth"
        transactions.add(createTx(testUser, rent, "Rent Feb", 1500, now.minusMonths(1).withDayOfMonth(1), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Groceries Feb", 100, now.minusMonths(1).withDayOfMonth(10), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, travel, "Flight Ticket", 400, now.minusMonths(1).withDayOfMonth(15), TransactionType.EXPENSE));

        // --- EXPENSES: LAST YEAR (For YoY Growth testing) ---
        transactions.add(createTx(testUser, rent, "Old Rent", 1200, now.minusYears(1).withMonth(6), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Bulk Food", 1000, now.minusYears(1).withMonth(5), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, travel, "Vacation", 2500, now.minusYears(1).withMonth(8), TransactionType.EXPENSE));

//        LocalDate now = LocalDate.now();
//        List<Transaction> transactions = new ArrayList<>();

// --- INCOME: Current vs Last Month vs Last Year ---
// Current Month (April 2026)
        transactions.add(createTx(testUser, salary, "Monthly Salary", 5000, now, TransactionType.INCOME));
        transactions.add(createTx(testUser, freelance, "Project Bonus", 1200, now.minusDays(5), TransactionType.INCOME));

// Previous Month (March 2026) - For MoM Growth
        transactions.add(createTx(testUser, salary, "Previous Month Salary", 5000, now.minusMonths(1), TransactionType.INCOME));

// Same Month Last Year (April 2025) - For YoY Growth
        transactions.add(createTx(testUser, salary, "Last Year Salary", 4500, now.minusYears(1), TransactionType.INCOME));


// --- EXPENSES: Current Month (April 2026) ---
        transactions.add(createTx(testUser, rent, "Monthly Rent", 1500, now.withDayOfMonth(1), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Grocery Shopping", 150, now.minusDays(2), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, travel, "Uber Ride", 45, now.minusDays(1), TransactionType.EXPENSE));


// --- EXPENSES: Last Month (March 2026) - For MoM testing ---
// Total here is 2000 vs current 1695 (Testing Negative Growth)
        transactions.add(createTx(testUser, rent, "Rent March", 1500, now.minusMonths(1).withDayOfMonth(1), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Groceries March", 100, now.minusMonths(1).withDayOfMonth(10), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, travel, "Flight Ticket", 400, now.minusMonths(1).withDayOfMonth(15), TransactionType.EXPENSE));


// --- EXPENSES: Last Year Same Month (April 2025) - For YoY testing ---
// Crucial: Use .minusYears(1) WITHOUT overriding the month
        transactions.add(createTx(testUser, rent, "Old Rent", 1200, now.minusYears(1).withDayOfMonth(1), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, food, "Bulk Food", 1000, now.minusYears(1).withDayOfMonth(5), TransactionType.EXPENSE));
        transactions.add(createTx(testUser, travel, "Vacation", 2500, now.minusYears(1).withDayOfMonth(15), TransactionType.EXPENSE));


        // --- MISC DATA TO REACH 20+ ---
        for(int i=1; i<=6; i++) {
            transactions.add(createTx(testUser, food, "Misc Snack " + i, 10 + i, now.minusDays(i + 10), TransactionType.EXPENSE));
        }

        transactionRepository.saveAll(transactions);
    }

    private Transaction createTx(User user, Category cat, String desc, double amt, LocalDate date, TransactionType type) {
        Transaction t = new Transaction();
        t.setIdentifierName(UUID.randomUUID().toString());
        t.setIdempotencyKey(UUID.randomUUID().toString()); // Unique for init
        t.setUser(user);
        t.setCategory(cat);
        t.setDescription(desc);
        t.setAmount(BigDecimal.valueOf(amt));
        t.setType(type);
        t.setCreatedAt(
                date);
        return t;
    }
}
