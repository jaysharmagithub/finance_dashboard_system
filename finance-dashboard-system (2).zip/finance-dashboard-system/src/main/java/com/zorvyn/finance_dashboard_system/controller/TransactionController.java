package com.zorvyn.finance_dashboard_system.controller;

import com.zorvyn.finance_dashboard_system.dto.TransactionDto;
import com.zorvyn.finance_dashboard_system.request.TransactionRequest;
import com.zorvyn.finance_dashboard_system.response.PaginatedResponse;
import com.zorvyn.finance_dashboard_system.response.SuccessResponse;
import com.zorvyn.finance_dashboard_system.service.TransactionService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.security.Principal;
/**
 * REST Controller for managing financial transactions.
 * Provides endpoints for CRUD operations and paginated history retrieval.
 *
 * <p><b>Security Policy:</b>
 * All endpoints require authentication. Specific methods enforce 'User Data Isolation'
 * by resolving the current user from the {@link Principal} object.
 */

@RestController
@RequestMapping("/transactions")
@RequiredArgsConstructor
@Slf4j
public class TransactionController {
    private final TransactionService transactionService;


    /**
     * Records a new financial transaction.
     * <p><b>Idempotency:</b> Requires a unique 'requestId' in the DTO to prevent duplicate processing.</p>
     *
     * @param transactionDto Validated transaction data from the client.
     * @return 201 Created on success.
     */
    @PreAuthorize("hasRole('USER') and #transactionDto.username() == principal.username")
    @PostMapping("/")
    public ResponseEntity<SuccessResponse<String>> addTransaction(@Valid @RequestBody TransactionRequest transactionDto,
                                                 HttpServletRequest request){
        log.info("REST request to save Transaction for user: {}", transactionDto.username());
        return SuccessResponse
                .created(transactionDto.requestId(),"Transaction completed successfully."
                        ,request.getRequestURI());
    }

    /**
     * Updates an existing transaction using its unique business identifier.
     *
     * @param identifier UUID-based identifierName.
     * @param transactionDto Updated transaction details.
     * @return 200 OK.
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or (hasRole('ROLE_USER') and #username == principal.username)")
    @PutMapping("/{identifier}")
    public ResponseEntity<String> updateTransaction(@PathVariable String identifier ,@RequestBody TransactionRequest transactionDto){
        transactionService.updateTransaction(identifier,transactionDto);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    /**
     * Retrieves the all-time total income for a specific user.
     * <p><b>Security:</b> Restricted to ADMIN or the owner of the account.</p>
     *
     * @param username The unique email/username of the user.
     * @return 200 OK with the total income as a BigDecimal.
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or (hasRole('ROLE_USER') and #username == principal.username)")
    @GetMapping("/{username}/income")
    public ResponseEntity<SuccessResponse<BigDecimal>> getTotalIncome(@PathVariable String username, HttpServletRequest request) {
        return SuccessResponse
                .ok(transactionService.getTotalIncome(username),"Total income retrieved successfully."
                        ,request.getRequestURI());
    }

    /**
     * Retrieves the all-time total expenses for a specific user.
     *
     * @param username The unique email/username of the user.
     * @return 200 OK with the total expenses as a BigDecimal.
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or (hasRole('ROLE_USER') and #username == principal.username)")
    @GetMapping("/{username}/expenses")
    public ResponseEntity<SuccessResponse<BigDecimal>> getTotalExpenses(@PathVariable String username,
                                                                        HttpServletRequest request) {
        return SuccessResponse
                .ok(transactionService.getTotalExpenses(username),"Total expenses retrieved successfully."
                        ,request.getRequestURI());
    }

    /**
     * Calculates the current net balance (Income - Expenses) for a user.
     *
     * @param username Provided via request parameter.
     * @return 200 OK with the calculated net balance.
     */
    @PreAuthorize("hasRole('ROLE_ADMIN') or (hasRole('ROLE_USER') and #username == principal.username)")
    @GetMapping("/balance")
    public ResponseEntity<SuccessResponse<BigDecimal>> getNetBalance(@RequestParam String username,
                                                                     HttpServletRequest request) {
        return SuccessResponse
                .ok(transactionService.getNetBalance(username),"Total income retrieved successfully."
                        ,request.getRequestURI());
    }

    /**
     * Fetches the most recent single transaction record for a user.
     *
     * @param username The unique email/username of the user.
     * @return 200 OK with the Transaction DTO.
     */
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ANALYST') or (hasRole('ROLE_USER') and #username == principal.username)")
    @GetMapping("/user/{username}")
    public ResponseEntity<SuccessResponse<TransactionDto>> getTransaction(@PathVariable String username,
                                                         @RequestParam String transactionId, HttpServletRequest request) {
        return SuccessResponse
                .ok(transactionService.getTranscation(username,transactionId),"Transaction retrieved successfully."
                        ,request.getRequestURI());
    }
    /**
     * Admin or Analyst only endpoint to view all transactions across the entire system.
     */
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ANALYST')")
    @GetMapping
    public ResponseEntity<SuccessResponse<PaginatedResponse<TransactionDto>>> getTransactions(
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "createdAt") String sortByField,
            @RequestParam(defaultValue = "DESC") String sortDirection,
            HttpServletRequest request) {
       Page<TransactionDto> transactions =  transactionService.getTranscations(pageNo, pageSize, sortByField, sortDirection);
       return PaginatedResponse
               .ok(transactions,"All Transactions retrieved successfully",request.getRequestURI());
    }

    /**
     * Retrieves paginated transaction history for the currently authenticated user.
     *
     * @param username Authenticated user context.
     * @param page Page number (0-indexed).
     * @param size Number of records per page.
     * @param sortBy Field to sort by (e.g., 'date').
     * @param direction Sort direction (ASC/DESC).
     * @return Paginated list of Transaction DTOs.
     */
    @GetMapping("/{username}")
    @PreAuthorize("hasAnyRole('ADMIN', 'VIEWER','ANALYST')or (hasRole('ROLE_USER') and #username == principal.username)")
    public ResponseEntity<SuccessResponse<PaginatedResponse<TransactionDto>>> getMyTransactions(
            @PathVariable String username,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "DESC") String direction,
            HttpServletRequest  request) {
        log.info("REST request to get transactions for user: {}, Page: {}", username, page);

        Page<TransactionDto> transactions = transactionService.getUserTransactions(
                username, page, size, sortBy, direction);
        return PaginatedResponse.ok(transactions,"User transactions retrieved successfully",request.getRequestURI());

    }
}
