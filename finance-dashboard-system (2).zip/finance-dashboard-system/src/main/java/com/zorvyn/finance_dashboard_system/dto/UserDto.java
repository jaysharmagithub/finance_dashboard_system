package com.zorvyn.finance_dashboard_system.dto;

import com.zorvyn.finance_dashboard_system.entity.Role;
import com.zorvyn.finance_dashboard_system.entity.User;
import jakarta.validation.constraints.*;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Set;

/**
 * Data Transfer Object for User information.
 *
 * This record acts as the primary contract for user-related requests.
 */
@Builder
public record UserDto(
        String firstName,
        String lastName,
        String mobileNo,
        String emailId,
        List<String> roles
) {

        /**
         * Converts a User Entity to a DTO for safe API responses.
         * Sensitive fields like 'password' are never mapped back to the DTO.
         */
        public static UserDto toDto(User user) {
                if (user == null) throw new IllegalArgumentException("User object can't be null");

                return UserDto.builder()
                        .emailId(user.getEmailId())
                        .firstName(user.getFirstName())
                        .lastName(user.getLastName()) // Fixed: Was mapping firstName to lastName in your snippet
                        .mobileNo(user.getMobileNo())
                        .roles(user.getRoles()
                                .stream()
                                .map(Role::getName)
                                .toList())
                        .build();
        }
}
