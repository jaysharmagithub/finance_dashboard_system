package com.zorvyn.finance_dashboard_system.response;

import lombok.Builder;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.Instant;
import java.util.List;

@Builder
public record PaginatedResponse<T>(
        List<T> content,
         int pageNumber,
         int pageSize,
         long totalElements,
         int totalPages,
         boolean last
) {

    public static <T> ResponseEntity<SuccessResponse<PaginatedResponse<T>>> ok(Page<T> page, String message, String path) {
        PaginatedResponse<T> data = PaginatedResponse.<T>builder()
                .content(page.getContent())
                .pageNumber(page.getNumber())
                .pageSize(page.getSize())
                .totalElements(page.getTotalElements())
                .totalPages(page.getTotalPages())
                .last(page.isLast())
                .build();
        return ResponseEntity.ok(
                SuccessResponse.<PaginatedResponse<T>>builder()
                        .status(HttpStatus.OK.value())
                        .message(message)
                        .data(data)
                        .timeStamp(Instant.now().toString())
                        .path(path)
                        .build()
        );

    }
}
