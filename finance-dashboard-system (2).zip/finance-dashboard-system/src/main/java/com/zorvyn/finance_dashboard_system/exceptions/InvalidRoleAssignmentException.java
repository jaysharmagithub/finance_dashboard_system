package com.zorvyn.finance_dashboard_system.exceptions;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a role assignment operation violates business rules.
 *
 * <p><b>Selection Detail:</b>
 * This ensures the integrity of the <b>RBAC Topology</b> by preventing redundant
 * assignments or invalid transitions. It acts as a safety layer for the
 * Domain-Driven helper methods in the {@link com.zorvyn.finance_dashboard_system.entity.Role} entity.</p>
 */
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidRoleAssignmentException extends RuntimeException {

    /**
     * Constructs the exception with a specific business rule violation message.
     *
     * @param message Detailed context, such as "The role is already assigned to this user."
     */
    public InvalidRoleAssignmentException(String message) {
        super(message);
    }
}
