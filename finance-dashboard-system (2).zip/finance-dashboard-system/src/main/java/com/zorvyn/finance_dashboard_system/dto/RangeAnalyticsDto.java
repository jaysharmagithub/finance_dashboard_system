package com.zorvyn.finance_dashboard_system.dto;

import java.math.BigDecimal;
import lombok.Builder;

/**
 * Aggregated Financial Snapshot for a specific date range.
 *
 * Used by the Dashboard to render high-level metrics like
 * Cash Flow summaries and Expense-to-Income ratios.
 */
@Builder
public record RangeAnalyticsDto(
        /* Total credit transactions within the selected period.
           Defaults to 0.00 in the service layer if no data exists. */
        BigDecimal income,

        /* Total debit transactions. Represented as a positive value
           for easier absolute comparison on the UI. */
        BigDecimal expense
) {
}
