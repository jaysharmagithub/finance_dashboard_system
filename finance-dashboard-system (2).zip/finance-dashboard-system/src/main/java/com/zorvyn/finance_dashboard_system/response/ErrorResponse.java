package com.zorvyn.finance_dashboard_system.response;

import lombok.Builder;

import java.time.LocalDateTime;
@Builder
public record ErrorResponse(
        int status,
        String error,
        String message,
        String path,
        LocalDateTime timestamp

) {}
