package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.RoleDto;
import com.zorvyn.finance_dashboard_system.entity.Role;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.exceptions.RoleNotFoundException;
import com.zorvyn.finance_dashboard_system.exceptions.UserNotFoundException;
import com.zorvyn.finance_dashboard_system.exceptions.RoleAlreadyExistsException;
import com.zorvyn.finance_dashboard_system.repository.RoleRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of Role Management operations.
 * Serves as the backbone for Role-Based Access Control (RBAC), managing:
 * <ul>
 *   <li>System-wide security authority definitions.</li>
 *   <li>Validation of role hierarchies and naming conventions.</li>
 *   <li>Administrative oversight of permission tiers.</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class RoleService implements IRoleService{
    private final RoleRepository roleRepository;
    private final UserRepository userRepository;

    /**
     * Initializes a new security role within the system.
     * <p><b>Selection Detail:</b> Enforces strict naming conventions (ROLE_ prefix)
     * and prevents duplicate authority definitions to maintain RBAC integrity.</p>
     *
     * @param role Data containing the role name.
     * @throws RoleAlreadyExistsException if a role with the same name is already defined.
     */
    @Override
    @Transactional
    public void createRole(String role) {
        log.info("Attempting to define a new security role: {}", role);
        String roleName = role.startsWith("ROLE_") ? role.toUpperCase() : "ROLE_" + role.toUpperCase();
       if(roleRepository.existsByName(roleName)){
           log.warn("Role definition failed: {} already exists in the registry.", role);
           throw new RoleAlreadyExistsException("The ROLE_"+role.toUpperCase()+" already exists.");
       }
        Role r = new Role(roleName);
        roleRepository.save(r);
        log.info("Security role {} successfully registered and active.", role);
    }

    /**
     * Bulk assigns a specific security role to multiple users.
     * <p><b>Selection Detail:</b> Optimized for administrative efficiency by processing
     * a collection of usernames in a single transactional boundary.</p>
     *
     * @param usernames List of user emails to be updated.
     * @param role      The role name to assign (e.g., 'ADMIN').
     */
    @Transactional
    @Override
    public void assignRoleToUsers(List<String> usernames, String role) {
        log.info("Bulk assignment: Granting role {} to {} users.", role, usernames.size());

        Role exist = roleRepository.findByName(role).orElseThrow(() -> {
            log.error("Bulk Assignment Failed: ROLE_{} not found.", role.toUpperCase());
            return new RoleNotFoundException("The ROLE_" + role.toUpperCase() + " not found.");
        });

        List<User> users = usernames.stream()
                .map(u -> userRepository.findByEmailId(u)
                        .orElseThrow(() -> {
                            log.warn("User {} not found during bulk role assignment.", u);
                            return new UserNotFoundException("User " + u + " not found.");
                        }))
                .toList();

        exist.assignRolesToUser(users);
        log.info("Successfully granted {} to all specified users.", role);
    }

    /**
     * Grants a specific security role to an individual user.
     * <p><b>Selection Detail:</b> Includes 'ROLE_' prefix enforcement and
     * user-existence verification to prevent inconsistent security states.</p>
     *
     * @param username The email identifier of the target user.
     * @param role     The name of the role (e.g., 'ADMIN').
     */
    @Override
    @Transactional
    public void assignRoleToUser(String username, String role) {
        log.info("Granting role {} to user: {}", role, username);

        String roleName = role.startsWith("ROLE_") ? role.toUpperCase() : "ROLE_" + role.toUpperCase();

        Role exist = roleRepository.findByName(roleName)
                .orElseThrow(() -> {
                    log.error("Assignment failed: Security role {} not found.", roleName);
                    return new RoleNotFoundException("The " + roleName + " not found.");
                });

        User user = userRepository.findByEmailId(username)
                .orElseThrow(() -> {
                    log.warn("Assignment failed: User {} does not exist.", username);
                    return new UserNotFoundException("User not found: " + username);
                });

        exist.assignRoleToUser(user);
        log.info("Successfully granted {} to user {}.", roleName, username);

    }

    /**
     * Removes a specific security role from multiple users.
     * <p><b>Critical Note:</b> This immediately revokes associated permissions
     * for the specified users across all secured endpoints.</p>
     *
     * @param usernames List of user emails.
     * @param role      The role name to revoke.
     */
    @Override
    @Transactional
    public void removeRoleFromUsers(List<String> usernames, String role) {
        log.warn("Bulk Revocation: Removing role {} from {} users.", role, usernames.size());

        Role exist = roleRepository.findByName(role).orElseThrow(() ->
                new RoleNotFoundException("The ROLE_" + role.toUpperCase() + " not found."));

        List<User> users = usernames.stream()
                .map(u -> userRepository.findByEmailId(u)
                        .orElseThrow(() -> new UserNotFoundException("User " + u + " not found.")))
                .toList();

        exist.removeRolesFromUser(users);
        log.info("Successfully revoked {} from all specified users.", role);
    }

    /**
     * Revokes a specific security role from an individual user.
     * <p><b>Critical Security Note:</b> This operation immediately restricts
     * the user's access permissions across all secured API endpoints.</p>
     */
    @Override
    @Transactional
    public void removeRoleFromUser(String username, String role) {
        log.warn("SECURITY ALERT: Revoking role {} from user: {}", role, username);

        String roleName = role.startsWith("ROLE_") ? role.toUpperCase() : "ROLE_" + role.toUpperCase();

        Role exist = roleRepository.findByName(roleName)
                .orElseThrow(() -> new RoleNotFoundException("The " + roleName + " not found."));

        User user = userRepository.findByEmailId(username)
                .orElseThrow(() -> new UserNotFoundException("User not found: " + username));

        exist.removeRoleFromUser(user);
        log.info("Successfully revoked {} from user {}.", roleName, username);
    }

    /**
     * Permanently removes a security role from the system.
     * <p><b>Critical Security Note:</b> This is a destructive operation that
     * globally revokes all user permissions associated with this role.</p>
     *
     * @param name The name of the role to purge.
     */
    @Override
    @Transactional
    public void deleteRole(String name) {
        log.warn("SECURITY ALERT: Permanent deletion requested for role: {}", name);
       roleRepository.findByName(name)
               .ifPresentOrElse(r -> {
                   roleRepository.deleteByName(r.getName());

                       },
               () -> {
                   log.error("Deletion failed: Role {} not found.", name);
                   throw new RoleNotFoundException("ROLE_ "+name.toUpperCase() +" not found.");
               });
    }

    /**
     * Retrieves all active security roles for administrative auditing.
     *
     * @return List of {@link RoleDto} representing the current system authorities.
     */
    @Transactional()
    @Override
    public List<RoleDto> getAllRoles() {
        log.debug("Auditing active security roles in the system.");
        return roleRepository.findAll().stream()
                .map(role -> new RoleDto(role.getName()))
                .collect(Collectors.toList());
    }
}
