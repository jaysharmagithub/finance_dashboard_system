package com.zorvyn.finance_dashboard_system.security;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Data Transfer Object (DTO) for handling user authentication attempts.
 * Uses a Java {@link Record} for immutability and concise data handling.
 *
 * <p><b>Selection Detail:</b>
 * Implements strict JSR-303 validation to ensure that malformed or empty
 * credentials are rejected at the Controller level, preserving server resources.</p>
 *
 * @param email    The user's unique primary identifier (must be a valid email format).
 * @param password The plain-text password submitted for verification against the hashed database value.
 */
public record LoginRequest(

        @NotBlank(message = "Email is required for authentication")
        @Email(message = "Please provide a valid email address")
        String email,

        @NotBlank(message = "Password cannot be empty")
        @Size(min = 8, message = "Password must meet the minimum security length of 8 characters")
        String password
) {
}
