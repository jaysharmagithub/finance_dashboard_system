package com.zorvyn.finance_dashboard_system.controller;

import com.zorvyn.finance_dashboard_system.dto.RoleDto;
import com.zorvyn.finance_dashboard_system.response.SuccessResponse;
import com.zorvyn.finance_dashboard_system.service.IRoleService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for Security Role and Authority Management.
 * This controller serves as the administrative interface for the system's
 * Role-Based Access Control (RBAC) topology.
 *
 * <p><b>Security Policy:</b>
 * All endpoints in this controller are strictly restricted to {@code ROLE_ADMIN}.
 * Unauthorized access attempts are logged for security auditing.</p>
 */
@RestController
@RequestMapping("/api/roles")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ROLE_ADMIN')")
@Slf4j
public class RoleController {

    private final IRoleService roleService;


    /**
     * Defines a new security authority in the system registry.
     *
     * @param role Data containing the role name (e.g., 'ADMIN', 'USER').
     * @return 201 Created on success.
     */
    @PostMapping
    public ResponseEntity<SuccessResponse<RoleDto>> createRole(@Valid @RequestBody RoleDto role, HttpServletRequest request) {
        log.warn("ADMIN ACTION: Defining new security role: {}", role.canonicalName());
        roleService.createRole(role.canonicalName());
        return SuccessResponse
                .created(
                        RoleDto.builder().name(role.canonicalName()).build()
                        ," Role created successfully"
                        ,request.getRequestURI());
    }

    /**
     * Bulk assigns a security role to a list of users.
     *
     * @param usernames List of user email identifiers.
     * @param role  The role to be granted.
     * @return 200 OK.
     */
    @PostMapping("/{role}/assignments/bulk")
    public ResponseEntity<SuccessResponse<List<String>>> assignRoleToUsers(
            @PathVariable String role,
            @RequestBody List<String> usernames, HttpServletRequest request
            ) {
        log.warn("ADMIN ACTION: Bulk assigning role {} to {} users", role, usernames.size());
        roleService.assignRoleToUsers(usernames, role);
        return SuccessResponse
                .ok(usernames,"Role assigned to " + usernames.size() + " users."
                        ,request.getRequestURI());
    }

    /**
     * Grants a specific security role to an individual user.
     * <p><b>Selection Detail:</b> Facilitates granular permission updates.
     * The service layer handles the 'ROLE_' prefix enforcement for consistency.</p>
     *
     * @param username The email identifier of the target user.
     * @param role     The name of the role (e.g., 'ADMIN', 'USER').
     * @return 200 OK with success message.
     */
    @PostMapping("/{role}/assignments/{username}")
    public ResponseEntity<SuccessResponse<String>> assignRoleToUser(
            @PathVariable String username,
            @PathVariable String role, HttpServletRequest request) {
        roleService.assignRoleToUser(username, role);
        return SuccessResponse
                .ok(username,"Role assigned to 1 users."
                        ,request.getRequestURI());
    }

    /**
     * Bulk revokes a specific security role from a list of users.
     * <p><b>Critical Note:</b> This operation immediately restricts system access
     * for all users in the provided list. Returns 204 No Content on success.</p>
     *
     * @param usernames List of user emails to be updated.
     * @param role      The role name to be removed.
     * @return 204 No Content.
     */
    @DeleteMapping("/{role}/assignments/bulk")
    public ResponseEntity<Void> removeRoleFromUsers(
            @RequestBody List<String> usernames,
            @PathVariable String role) {

        log.warn("ADMIN ACTION: Bulk revoking role {} from {} users", role, usernames.size());
        roleService.removeRoleFromUsers(usernames, role);
        return ResponseEntity.noContent().build();
    }

    /**
     * Removes a specific security role from an individual user.
     *
     * @param username The target user's email.
     * @param role The role to be revoked.
     * @return 200 OK.
     */
    @DeleteMapping("/{role}/assignments/{username}")
    public ResponseEntity<Void> removeRoleFromUser(
            @PathVariable String role,
            @PathVariable String username) {
        log.warn("ADMIN ACTION: Revoking role {} from user: {}", role, username);
        roleService.removeRoleFromUser(username, role);
        return ResponseEntity.noContent().build();
    }

    /**
     * Retrieves all active security roles for system auditing.
     */
    @GetMapping
    public ResponseEntity<SuccessResponse<List<RoleDto>>> getAllRoles(HttpServletRequest request) {
        log.info("ADMIN ACCESS: Auditing all system roles.");
         return SuccessResponse
                 .ok(roleService.getAllRoles(),"All roles retrieved successfully" ,request.getRequestURI());

    }
    /**
     * deletes a role definition from the system.
     */
    @DeleteMapping("/{name}")
    public ResponseEntity<Void> deleteRole(@PathVariable String name) {
        log.error("CRITICAL ADMIN ACTION: Deleting role definition: {}", name );
        roleService.deleteRole(name);
        return ResponseEntity.noContent().build();
    }
}

