package com.zorvyn.finance_dashboard_system.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a requested Security Role cannot be located in the system registry.
 *
 * <p><b>Selection Detail:</b>
 * This ensures the integrity of the <b>RBAC (Role-Based Access Control)</b> system.
 * By throwing a 404 Not Found, the system prevents invalid authorization states
 * and provides clear feedback during administrative role-assignment tasks.</p>
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class RoleNotFoundException extends RuntimeException {

    /**
     * Constructs a new exception with a specific error message.
     *
     * @param message Detailed context (e.g., "The role 'ROLE_ADMIN' was not found").
     */
    public RoleNotFoundException(String message) {
        super(message);
    }
}
