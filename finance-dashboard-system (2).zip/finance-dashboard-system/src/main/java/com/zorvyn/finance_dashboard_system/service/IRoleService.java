package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.RoleDto;
import jakarta.transaction.Transactional;

import java.util.List;

public interface IRoleService {
    void createRole(String role);
    void assignRoleToUsers(List<String> usernames, String role);
    void assignRoleToUser(String username, String role);
    void removeRoleFromUsers(List<String> usernames, String role);
    void removeRoleFromUser(String username, String role);
    void deleteRole(String name);
    List<RoleDto> getAllRoles();
}
