package com.zorvyn.finance_dashboard_system.controller;

import com.zorvyn.finance_dashboard_system.dto.UserDto;
import com.zorvyn.finance_dashboard_system.request.UserRequest;
import com.zorvyn.finance_dashboard_system.response.PaginatedResponse;
import com.zorvyn.finance_dashboard_system.response.SuccessResponse;
import com.zorvyn.finance_dashboard_system.service.IUserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

/**
 * REST Controller for Managing User Profiles and Identities.
 * Enforces strict security boundaries between standard users and administrators.
 *
 * <p><b>Security Standards:</b>
 * <ul>
 *   <li>Uses {@link Principal} to resolve 'Self' for profile updates.</li>
 *   <li>Enforces {@code ROLE_ADMIN} for global user listing and destructive actions.</li>
 *   <li>Applies Bean Validation (@Valid) to all incoming payloads.</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Slf4j
public class UserController {

    private final IUserService userService;

    /**
     * Public endpoint for new account creation.
     * Enforces the 'Secure-by-Default' policy by encoding passwords at the service layer.
     */
    @PostMapping("/register")
    public ResponseEntity<SuccessResponse<UserRequest>> addUser(@RequestBody @Valid UserRequest userDto,
                                                            HttpServletRequest request) {
        log.info("REST: New registration attempt for email: {}", userDto.emailId());
        userService.addUser(userDto);
        return SuccessResponse.created(userDto  ,"User registered successfully",request.getRequestURI());
    }

    /**
     * Administrative override to modify a user account by its internal primary key.
     * <p><b>Note:</b> Typically used for customer support or system maintenance.</p>
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> updateUserById(@PathVariable Long id, @RequestBody @Valid UserDto userDto) {
        userService.updateUser(id, userDto);
        return ResponseEntity.noContent().build();
    }

    /**
     * Self-service endpoint for profile modifications.
     * Enforces strict ownership: USERS can only update themselves.
     */
    @PatchMapping("/{username}")
    @PreAuthorize("hasRole('ADMIN') or (hasRole('USER') and #username == principal.username)")
    public ResponseEntity<String> updateCurrentUser(@PathVariable String username, @RequestBody @Valid UserRequest userDto) {
        userService.updateUser(username, userDto);
        return ResponseEntity.noContent().build();
    }

    /**
     * Decommissioning endpoint for user accounts.
     * Returns 204 No Content as per REST best practices for deletions.
     */
    @DeleteMapping("/{username}")
    @PreAuthorize("hasRole('ADMIN') or (hasRole('USER') and #username == principal.username)")
    public ResponseEntity<Void> deleteUser(@PathVariable String username) {
        userService.deleteUser(username);
        return ResponseEntity.noContent().build();
    }

    /**
     * Administrative endpoint for global user audits.
     * Leverages Spring Data Pagination to handle large datasets efficiently.
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<SuccessResponse<PaginatedResponse<UserDto>>> getAllUsers(
            @RequestParam(defaultValue = "0") int pageNo,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "id") String sortByField,
            @RequestParam(defaultValue = "ASC") String sortDirection,
            HttpServletRequest request) {
        Page<UserDto>  users = userService.getUsers(pageNo, pageSize, sortByField, sortDirection);
         return  PaginatedResponse.
               ok(users,"All Transactions retrieved successfully",request.getRequestURI());
    }

    /**
     * Retrieves detailed profile information for a specific user.
     */
    @PreAuthorize("hasRole('ADMIN') or (hasRole('USER') and #username == principal.username)")
    @GetMapping("/{username}")
    public ResponseEntity<SuccessResponse<UserDto>> getUser(@PathVariable String username, HttpServletRequest request) {
        return SuccessResponse.
                ok(userService.getUser(username),
                        "User details retrieved successfully",
                        request.getRequestURI()
                );

    }
}
