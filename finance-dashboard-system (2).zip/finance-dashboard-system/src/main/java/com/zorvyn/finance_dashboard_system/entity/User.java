package com.zorvyn.finance_dashboard_system.entity;

import com.zorvyn.finance_dashboard_system.dto.UserDto;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core entity representing a system user and security principal.
 * This class implements {@link UserDetails} to integrate directly with Spring Security.
 *
 * <p><b>Key Features:</b>
 * <ul>
 *   <li><b>RBAC:</b> Supports Many-to-Many relationship with {@link Role} for granular permissions.</li>
 *   <li><b>Ownership:</b> Acts as the parent for all {@link Transaction} records.</li>
 *   <li><b>Security:</b> Stores Bcrypt-encoded passwords and manages account status flags.</li>
 * </ul>
 */
@Table(name = "users", indexes = {
        @Index(name = "idx_user_email", columnList = "email_id", unique = true)
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@AttributeOverride(name = "id", column = @Column(name = "user_id"))
public class User extends BaseUseCase implements UserDetails {

    /**
     * The legal first name of the user.
     * Used for personalising the dashboard and communication.
     */
    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;
    /**
     * The legal last name (surname) of the user.
     */
    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;
    /**
     * The user's primary contact number.
     * <b>Selection Detail:</b> Stored as a string to accommodate international
     * formatting and leading zeros.
     */
    @Column(unique = true, nullable = false)
    private String mobileNo;
    /**
     * The user's primary email address.
     * Serves as the unique 'username' for authentication purposes.
     */
    @Column(unique = true, nullable = false)
    private String emailId;

   /**
     * Securely hashed password.
     * <b>Security Note:</b> Never stores plain-text; must be encoded using BCrypt.
     */
    @Column(nullable  = false)
    private String password;

    /**
     * Set of roles defining the user's permissions (e.g., ROLE_ADMIN, ROLE_USER).
     * Loaded Eagerly to ensure authorities are available immediately upon authentication.
     */
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();
    /**
     * Collection of transactions owned by this user.
     * Mapped with Lazy loading to optimize memory during standard user lookups.
     */
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL)
    private List<Transaction> transactions = new ArrayList<>();


    private boolean accountNonExpired;
    private boolean accountNonLocked;
    private boolean credentialsNonExpired;
    private boolean enable;


    @PrePersist
    public void onCreate(){
        this.accountNonExpired = true;
        this.accountNonLocked = true;
        this.credentialsNonExpired = true;
        this.enable = true;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        return id != null && id.equals(((User) o).id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }


    /**
     * Maps the internal Role entities to Spring Security's GrantedAuthority format.
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles
                .stream()
                .map(r -> new SimpleGrantedAuthority(r.getName()))
                .collect(Collectors.toSet());
    }

    /**
     * @return
     */
    @Override
    public String getPassword() {
        return this.password;
    }

    /**
     * @return
     */
    @Override
    public String getUsername() {
        return this.emailId;
    }


    /**
     * @return
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * @return
     */
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    /**
     * @return
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * @return
     */
    @Override
    public boolean isEnabled() {
        return true;
    }
}
