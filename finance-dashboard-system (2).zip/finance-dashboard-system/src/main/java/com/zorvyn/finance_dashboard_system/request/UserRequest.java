package com.zorvyn.finance_dashboard_system.request;

import com.zorvyn.finance_dashboard_system.entity.User;
import jakarta.validation.constraints.*;
import lombok.Builder;

/**
 * Data Transfer Object for User information.
 *
 * This record acts as the primary contract for user-related requests.
 * It enforces strict validation rules to ensure data integrity before
 * it ever touches our database or business logic.
 */
@Builder
public record UserRequest(

        /* Validates name strings while allowing for international
           naming conventions (hyphens, spaces, etc.) */
        @NotBlank(message = "First name is mandatory for identification.")
        @Size(min = 1, max = 50, message = "First name must be between 1 and 50 characters.")
        @Pattern(
                regexp = "^[A-Za-z]+([ '-][A-Za-z]+)*$",
                message = "Please use valid characters for the first name (Letters, spaces, hyphens)."
        )
        String firstName,

        @Size(max = 50, message = "Last name cannot exceed 50 characters.")
        @Pattern(
                regexp = "^[A-Za-z]*([ '-][A-Za-z]+)*$",
                message = "Please use valid characters for the last name."
        )
        String lastName,

        /* Password is required on input but intentionally excluded
           from the toDto conversion for security. */
        @NotBlank(message = "A secure password is required.")
        String password,

        /* Strict validation for Indian mobile numbers to ensure
           SMS/OTP services function correctly. */
        @NotBlank(message = "Mobile number is required for account security.")
        @Pattern(
                regexp = "^[6-9]\\d{9}$",
                message = "Please provide a valid 10-digit Indian mobile number."
        )
        String mobileNo,

        @NotBlank(message = "Email address is mandatory.")
        @Email(message = "The email format provided is invalid.")
        @Size(max = 100, message = "Email is too long; please use a standard address.")
        String emailId
) {

    /**
     * Maps the incoming DTO to a User Entity.
     * Note: Password hashing should be handled in the Service layer,
     * not during this conversion.
     */
    public static User toEntity(UserRequest dto) {
        if (dto == null) {
            throw new IllegalArgumentException("Cannot map a null UserDto to an Entity.");
        }

        return User.builder()
                .firstName(dto.firstName())
                .lastName(dto.lastName())
                .mobileNo(dto.mobileNo())
                .emailId(dto.emailId())
                .build();
    }

    /**
     * Converts a User Entity to a DTO for safe API responses.
     * Sensitive fields like 'password' are never mapped back to the DTO.
     */
    public static UserRequest toDto(User user) {
        if (user == null) return null;

        return UserRequest.builder()
                .emailId(user.getEmailId())
                .firstName(user.getFirstName())
                .lastName(user.getLastName()) // Fixed: Was mapping firstName to lastName in your snippet
                .mobileNo(user.getMobileNo())
                .build();
    }
}

