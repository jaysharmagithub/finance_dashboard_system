package com.zorvyn.finance_dashboard_system.controller;

import com.zorvyn.finance_dashboard_system.dto.*;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import com.zorvyn.finance_dashboard_system.response.SuccessResponse;
import com.zorvyn.finance_dashboard_system.service.IDashboardService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
/**
 * Financial Dashboard.
 *
 * This controller acts as the primary data engine for the financial dashboard.
 * It transforms raw transaction data into high-level KPIs, growth trends,
 * and spending breakdowns while ensuring strict data isolation per user.
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard", description = "Financial overview and growth analytics")
public class DashboardController {

    private final IDashboardService dashboardService;

    /**
     * Entry point for the dashboard UI.
     * Aggregates all financial metrics (Totals, Growth %, and Recent Activity)
     * into a single high-performance response.
     *
     * @param principal Authenticated user context.
     * @return DashboardSummaryDto containing the complete dashboard state.
     */
    @PreAuthorize("hasAnyRole('USER', 'ADMIN', 'VIEWER')")
    @GetMapping("/summary")
    public ResponseEntity<SuccessResponse<DashboardSummaryDto>> getDashboardSummary(Principal principal,
                                                                                    HttpServletRequest request) {
        // principal.getName() provides the authenticated email/username
        log.info("[Dashboard] Loading main summary for user: {}", principal.getName());
        DashboardSummaryDto summary = dashboardService.getDashboard(principal.getName());
        return SuccessResponse.ok(summary,"Financial summary retrieved successfully" ,request.getRequestURI());
    }

    /**
     * Categorized spending breakdown for visualization.
     *
     * @param type Filter by 'INCOME' or 'EXPENSE' (Defaults to EXPENSE for charts).
     * @return List of categories with their cumulative monetary totals.
     */
    @GetMapping("/categories")
    public ResponseEntity<SuccessResponse<List<CategorywiseSummaryDto>>> getCategorySummary(
            Principal principal,
            @RequestParam(defaultValue = "EXPENSE") TransactionType type, HttpServletRequest request) {
        log.debug("[Dashboard] Category breakdown requested for: {} (Type: {})", principal.getName(), type);
        Long userId = dashboardService.getUserId(principal.getName());
        return SuccessResponse.ok(
                dashboardService.getCategoryWiseTotal(userId,type),
                "Categorized spending retrieved successfully",
                request.getRequestURI()

        );
    }

    /**
     * Calculates financial velocity (MoM and YoY).
     * <p><b>Logic:</b> Essential for showing 'Green/Red' trend indicators on the UI.</p>
     */
    @GetMapping("/growth")
    public ResponseEntity<SuccessResponse<GrowthMetricesDto>> getGrowthMetrics(Principal principal,
                                                                               HttpServletRequest request) {
        LocalDate now = LocalDate.now();
        Long userId = dashboardService.getUserId(principal.getName());
        double mom = dashboardService.calculateMonthOverMonthGrowth(userId, now);
        double yoy = dashboardService.calculateYearOverYearGrowth(userId, now);
        return SuccessResponse.ok(
                GrowthMetricesDto.builder().mom(mom).yoy(yoy).build(),
                "Mom and YoY retrieved successfully",
                request.getRequestURI()

        );
    }
    /**
     * Custom Date-Range Analytics.
     * <p><b>Validation:</b> Ensures the start date is chronologically before the end date.</p>
     *
     * @param dateRangeFilter date range filter of the report period.
     */
    @GetMapping("/analytics/range")
    public ResponseEntity<SuccessResponse<RangeAnalyticsDto>> getRangeAnalytics(
            Principal principal,@Valid DateRangeFilter dateRangeFilter, HttpServletRequest request) {
        BigDecimal income = dashboardService.getIncome(principal.getName(), dateRangeFilter);
        BigDecimal expense = dashboardService.getExpenses(principal.getName(), dateRangeFilter);
        return SuccessResponse.ok(
                RangeAnalyticsDto.builder().income(income).expense(expense).build(),
                "Analytics retrieved successfully",
                request.getRequestURI()

        );

    }

}
