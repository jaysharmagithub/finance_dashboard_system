package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.CategorywiseSummaryDto;
import com.zorvyn.finance_dashboard_system.dto.DashboardSummaryDto;
import com.zorvyn.finance_dashboard_system.dto.DateRangeFilter;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface IDashboardService {
    List<CategorywiseSummaryDto> getCategoryWiseTotal(Long userId, TransactionType type);
    DashboardSummaryDto getDashboard(String username);
    CategorywiseSummaryDto topExpenseCategoryDto(Long userId);
    BigDecimal getExpenses(String username, DateRangeFilter dateRangeFilter);
    BigDecimal getIncome(String username, DateRangeFilter dateRangeFilter);
    double calculateMonthOverMonthGrowth(Long userId, LocalDate now);
    double calculateYearOverYearGrowth(Long userId, LocalDate now);
    BigDecimal getCurrentYearExpense(Long userId, LocalDate now);
    BigDecimal getLastYearExpense(Long userId);
    BigDecimal getCurrentMonthExpense(Long userId, LocalDate now);
    BigDecimal getLastMonthExpense(Long userId);
    Long getUserId(String username);
}
