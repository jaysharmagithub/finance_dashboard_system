package com.zorvyn.finance_dashboard_system.repository;

import com.zorvyn.finance_dashboard_system.entity.Role;
import com.zorvyn.finance_dashboard_system.entity.User;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import java.util.Optional;

/**
 * Repository interface for {@link Role} entity.
 * Provides abstracted data access for system-level security roles and permissions.
 *
 * <p><b>Standards:</b>
 * <ul>
 *   <li>Inherits standard CRUD operations from {@link JpaRepository}.</li>
 *   <li>Implements 'Null-Safe Retrieval' to prevent application crashes during role assignment.</li>
 *   <li>Supports unique role resolution (e.g., ROLE_ADMIN, ROLE_USER) for Spring Security.</li>
 * </ul>
 */
public interface RoleRepository extends JpaRepository<Role,Long> {
    /**
     * Resolves a security role by its unique name.
     * <p><b>Implementation Note:</b> This is used primarily during user registration
     * and privilege escalation to find a specific role (e.g., 'ROLE_USER').</p>
     *
     * @param name The unique name of the role (must be prefixed with 'ROLE_').
     * @return An {@link Optional} containing the Role if found, or empty otherwise.
     */
    Optional<Role> findByName(String name);
    /**
     * Checks if a specific role already exists in the system.
     * Used during system startup or by admins to prevent duplicate role definitions.
     *
     * @param name The name of the role to verify.
     * @return true if the role exists, false otherwise.
     */
    boolean existsByName(String name);

    /**
     * Permanent removal of a security role from the system.
     *
     * <p><b>Critical Security Note:</b>
     * Due to the Many-to-Many relationship with {@link User}, this operation
     * will remove the association in the 'user_roles' join table.
     * Use with extreme caution as it globally revokes permissions associated
     * with this role name.</p>
     *
     * @param name The unique name of the role (e.g., 'ROLE_ADMIN') to be purged.
     */
    @Transactional
    @Modifying
    void deleteByName(String name);

}
