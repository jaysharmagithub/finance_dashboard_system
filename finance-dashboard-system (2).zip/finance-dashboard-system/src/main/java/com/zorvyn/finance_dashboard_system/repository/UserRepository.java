package com.zorvyn.finance_dashboard_system.repository;

import com.zorvyn.finance_dashboard_system.entity.User;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
/**
 * Repository interface for {@link User} entity.
 * Provides abstracted data access for user-related identity and security operations.
 *
 * <p><b>Standards:</b>
 * <ul>
 *   <li>Extends {@link JpaRepository} to leverage built-in pagination, sorting, and batch CRUD.</li>
 *   <li>Enforces 'Identity Isolation' by using unique email lookups for authentication.</li>
 *   <li>Utilizes {@link Optional} return types to avoid {@code NullPointerException} in service logic.</li>
 * </ul>
 */
@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    /**
     * Checks for the existence of a user by their unique email.
     * Essential for registration logic to prevent duplicate identity creation.
     *
     * @param username The unique email address to check.
     * @return true if an account exists with this email, false otherwise.
     */
   boolean existsByEmailId(String username);
    /**
     * Resolves a user entity by its primary security identifier (email).
     * Used by the {@code UserDetailsService} during the Spring Security login flow.
     *
     * @param username The unique email/username of the user.
     * @return An {@link Optional} containing the User if found, or empty if not.
     */
    Optional<User> findByEmailId(String username);


    /**
     * Permanent removal of a user account based on their unique email.
     * <p><b>Execution Detail:</b> This operation triggers cascading deletes
     * for all associated transactions and role mappings as defined in the
     * {@link User} entity mapping.</p>
     *
     * @param emailId The unique email/username of the user to be purged.
     */
    void deleteByEmailId(String emailId);

    /**
     * Resolves a user identity using their registered mobile number.
     * <p><b>Selection Detail:</b> Used for secondary authentication flows,
     * password recovery, or unique contact verification.</p>
     *
     * @param mobileNo The mobile number string.
     * @return An {@link Optional} containing the user if found.
     */
    Optional<User> findByMobileNo(String mobileNo);


    boolean existsByMobileNo(String s);
    /**
     * Custom JPQL query for high-performance lookup of specific user profile data.
     * <b>Pro Tip:</b> Using @Query prevents N+1 problems in complex relationships.
     *
     * @param emailId The user's primary email.
     * @return The User entity with roles eagerly loaded (if defined in @Query).
     */
    @Query("SELECT u FROM User u WHERE u.emailId = :emailId")
    Optional<User> findUserWithRoles(@Param("emailId") String emailId);
}
