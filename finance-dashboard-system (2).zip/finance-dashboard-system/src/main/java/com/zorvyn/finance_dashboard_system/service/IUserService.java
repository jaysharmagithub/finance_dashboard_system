package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.UserDto;
import com.zorvyn.finance_dashboard_system.request.UserRequest;
import org.springframework.data.domain.Page;

public interface IUserService {
    void addUser(UserRequest userDto);
    void updateUser(Long id, UserDto userDto);
    void deleteUser(String username);
    void updateUser(String username, UserRequest userDto);
    Page<UserDto> getUsers(int  pageNo, int pageSize, String sortByField,  String sortDirection);
    UserDto getUser(String username);
}
