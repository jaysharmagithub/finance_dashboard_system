package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.CategorywiseSummaryDto;
import com.zorvyn.finance_dashboard_system.dto.DashboardSummaryDto;
import com.zorvyn.finance_dashboard_system.dto.DateRangeFilter;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.enums.SortingType;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import com.zorvyn.finance_dashboard_system.exceptions.UserNotFoundException;
import com.zorvyn.finance_dashboard_system.repository.TransactionRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import com.zorvyn.finance_dashboard_system.util.DateUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DashboardService implements IDashboardService{
     private final TransactionService transactionService;
     private final TransactionRepository transactionRepository;
     private final UserRepository userRepository;

    /**
     * @return
     */
    @Override
    public List<CategorywiseSummaryDto> getCategoryWiseTotal(Long userId, TransactionType type) {
     return transactionRepository.findCategoryTotalsByUserIdAndType(userId,type);
    }


    @Override
    public DashboardSummaryDto getDashboard(String username){
        LocalDate now = LocalDate.now();
        Long userId = getUserId(username);
        return new DashboardSummaryDto(
                totalIncome(userId),
                totalExpenses(userId),
                netBalance(userId),
                topExpenseCategoryDto(userId),
                calculateMonthOverMonthGrowth(userId,now),
                calculateYearOverYearGrowth(userId,now),
                getCategoryWiseTotal(userId,TransactionType.EXPENSE),
                transactionService
                        .getUserTransactions(username,0,5,"createdAt", SortingType.DESC.name())
                        .toList()
                );
    }

    private BigDecimal totalIncome(Long userId){
       BigDecimal income =  transactionRepository
                .sumByUserIdAndType(userId,TransactionType.INCOME);
        return (income != null ? income : BigDecimal.ZERO);
    }

    private BigDecimal totalExpenses(Long userId){
       BigDecimal expenses =  transactionRepository
                .sumByUserIdAndType(userId,TransactionType.EXPENSE);
        return  expenses != null ? expenses : BigDecimal.ZERO;
    }


    private BigDecimal netBalance(Long userId) {
        return totalIncome(userId)
                .subtract(totalExpenses(userId));
    }

    @Override
    public CategorywiseSummaryDto topExpenseCategoryDto(Long userId){
        List<CategorywiseSummaryDto> results = transactionRepository
                .findTopCategory(userId, TransactionType.EXPENSE, PageRequest.of(0, 1));
        return results.isEmpty()
                ? new CategorywiseSummaryDto("No expenses yet",BigDecimal.ZERO)
                : results.get(0);
    }

    @Override
    public BigDecimal getExpenses(String username, DateRangeFilter dateRangeFilter){
        Long userId = getUserId(username);
        return transactionRepository.sumByUserAndTypeAndDateRange(
                        userId,
                        TransactionType.EXPENSE,
                        dateRangeFilter.startDate(), dateRangeFilter.endDate()
                );
    }

    @Override
    public BigDecimal getIncome(String username, DateRangeFilter dateRangeFilter){
        Long userId = getUserId(username);
        return transactionRepository.sumByUserAndTypeAndDateRange(
                userId,
                TransactionType.INCOME,
                dateRangeFilter.startDate(), dateRangeFilter.endDate()
        );
    }

    @Override
    public double calculateMonthOverMonthGrowth(Long userId,LocalDate now){
        BigDecimal currentMonth = getCurrentMonthExpense(userId,now);
        BigDecimal lastMonth = getLastMonthExpense(userId);
        if(lastMonth == null || lastMonth.compareTo(BigDecimal.ZERO) == 0) return 0.0;
        return currentMonth
                .subtract(lastMonth)
                .divide(lastMonth,4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .doubleValue();
    }

    @Override
    public double calculateYearOverYearGrowth(Long userId,LocalDate now){
        BigDecimal currentYear = getCurrentYearExpense(userId,now);
        BigDecimal lastYear = getLastYearExpense(userId);
        BigDecimal safeCurrent = (currentYear != null) ? currentYear : BigDecimal.ZERO;
        BigDecimal safeLast = (lastYear != null) ? lastYear : BigDecimal.ZERO;
        if (safeLast.compareTo(BigDecimal.ZERO) == 0) return 0.0;
        return safeCurrent.subtract(safeLast)
                .divide(safeLast, 4, RoundingMode.HALF_UP)
                .multiply(BigDecimal.valueOf(100))
                .doubleValue();
    }

    @Override
    public Long getUserId(String username) {
        return userRepository.findByEmailId(username)
                .map(User::getId)
                .orElseThrow(() -> new UserNotFoundException("User doesn't exist: " + username));
    }


    @Override
    public BigDecimal getCurrentYearExpense(Long userId, LocalDate now){
       return transactionRepository
                .sumByUserAndTypeAndDateRange(
                        userId,
                        TransactionType.EXPENSE,
                        DateUtil.getStartOfCurrentYear(), now
                );

    }
    @Override
    public BigDecimal getLastYearExpense(Long userId){
        return transactionRepository.sumByUserAndTypeAndDateRange(
                userId,
                TransactionType.EXPENSE,
                DateUtil.getStartOfLastYear(),
                DateUtil.getEndOfLastYear()

        );
    }

    @Override
    public BigDecimal getCurrentMonthExpense(Long userId, LocalDate now){
        return transactionRepository
                .sumByUserAndTypeAndDateRange(
                        userId,
                        TransactionType.EXPENSE,
                        DateUtil.getStartOfCurrentMonth(), now
                );

    }
    @Override
    public BigDecimal getLastMonthExpense(Long userId){
        return transactionRepository.sumByUserAndTypeAndDateRange(
                userId,
                TransactionType.EXPENSE,
                DateUtil.getStartOfLastMonth(),
                DateUtil.getEndOfLastMonth()

        );
    }
}
