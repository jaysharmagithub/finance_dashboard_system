package com.zorvyn.finance_dashboard_system.security;

import com.zorvyn.finance_dashboard_system.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;

/**
 * Main Security Infrastructure.
 *
 * This class handles the "Gatekeeper" logic for our API.
 * It’s configured to allow public access to auth/registration endpoints
 * while keeping all internal business logic behind a mandatory authentication wall.
 *
 * Key Strategies:
 * - Session Management: 'IF_REQUIRED' (Balances stateful sessions with API flexibility).
 * - Stateless Context: Uses a custom SecurityContextRepository to bridge requests.
 * - Logout: Complete cleanup (Session invalidation + Cookie removal).
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
@Slf4j
public class SecurityConfig {
    private final SecurityContextRepository securityContextRepository;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
        http.csrf(AbstractHttpConfigurer::disable)
//                .csrf(csrf -> csrf
//                        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
//                        .csrfTokenRequestHandler(new CsrfTokenRequestAttributeHandler()))
                .authorizeHttpRequests(auth -> {
                    log.debug("Configuring request authorization rules.");
                        auth
                        // Publicly accessible endpoints (Auth, Registration, and Error handling)
                        .requestMatchers("/api/auth/**","/api/users/register", "/v3/api-docs/**",
                                " /swagger-ui/**",  "/swagger-ui.html").permitAll()
                        // Everything else requires a valid session/token
                        .anyRequest().authenticated();
                })
                // Using a custom logout flow to ensure sessions are cleared and cookies are nuked
                .logout(logout -> logout
                .logoutUrl("/api/auth/logout")
                        .addLogoutHandler((request, response, authentication) -> {
                            if (authentication != null) {
                                log.info("User '{}' is logging out.", authentication.getName());
                            }
                        })
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID"))
                // Plugging in our shared repository to persist security context across requests
                .securityContext(context -> context
                        .securityContextRepository(securityContextRepository)
                )
                // We create sessions only when needed (e.g., after successful login)
                // This balances statelessness with the need for persistent user context.
                .sessionManagement(session -> {
                        log.debug("Setting session policy to IF_REQUIRED.");
                        session
                        .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED);
                });
        return http.build();

    }

}
