package com.zorvyn.finance_dashboard_system.dto;

import lombok.Builder;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

/**
 * The 'Single Source of Truth' for the User Dashboard.
 *
 * Aggregates financial totals, growth trends, and categorized breakdowns
 * into a single response to minimize API round-trips for the frontend.
 */
@Builder
public record DashboardSummaryDto(
        /* High-level liquidity metrics. Using BigDecimal for
           monetary precision to avoid floating-point errors. */
        BigDecimal totalIncome,
        BigDecimal totalExpenses,
        BigDecimal netBalance,

        /* Insight-driven: Highlight the category draining the
           most funds this period. */
        CategorywiseSummaryDto topExpenseCategory,

        /* Trend percentages. 0.0 indicates a neutral or new state. */
        double monthlyGrowth,
        double yearlyGrowth,

        /* Detailed lists for charts and activity feeds. */
        List<CategorywiseSummaryDto> categoryBreakdown,
        List<TransactionDto> recentTransactions
) {
    /**
     * Compact Constructor for Production Safety.
     * Ensures lists are never null to prevent frontend mapping errors.
     */
    public DashboardSummaryDto {
        if (categoryBreakdown == null) categoryBreakdown = Collections.emptyList();
        if (recentTransactions == null) recentTransactions = Collections.emptyList();

        if (totalIncome == null) totalIncome = BigDecimal.ZERO;
        if (totalExpenses == null) totalExpenses = BigDecimal.ZERO;
        if (netBalance == null) netBalance = totalIncome.subtract(totalExpenses);
    }

    /**
     * Logic-Check: Is the user currently spending more than they earn?
     * This helps the UI quickly trigger a 'Low Balance' or 'High Spending' alert.
     */
    public boolean isDeficit() {
        return totalExpenses.compareTo(totalIncome) > 0;
    }
}
