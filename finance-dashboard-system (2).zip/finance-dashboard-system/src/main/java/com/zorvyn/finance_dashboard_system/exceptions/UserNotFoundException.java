package com.zorvyn.finance_dashboard_system.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a requested User identity cannot be located in the system.
 *
 * <p><b>Selection Detail:</b>
 * This is a core security exception used by the {@code UserDetailsService} and
 * profile management APIs. It ensures that the system returns a standard
 * <b>404 Not Found</b>, preventing NullPointerExceptions during
 * sensitive authentication handshakes.</p>
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class UserNotFoundException extends RuntimeException {

    /**
     * Constructs a new exception with a specific identity message.
     *
     * @param message Detailed context (e.g., "User with email 'john@example.com' not found").
     */
    public UserNotFoundException(String message) {
        super(message);
    }
}

