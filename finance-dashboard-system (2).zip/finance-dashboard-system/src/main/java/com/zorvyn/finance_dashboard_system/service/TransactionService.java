package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.TransactionDto;
import com.zorvyn.finance_dashboard_system.entity.Category;
import com.zorvyn.finance_dashboard_system.entity.Transaction;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.enums.TransactionType;
import com.zorvyn.finance_dashboard_system.exceptions.CategoryNotFoundException;
import com.zorvyn.finance_dashboard_system.exceptions.DuplicateTransactionException;
import com.zorvyn.finance_dashboard_system.exceptions.TransactionNotFoundException;
import com.zorvyn.finance_dashboard_system.exceptions.UserNotFoundException;
import com.zorvyn.finance_dashboard_system.repository.CategoryRepository;
import com.zorvyn.finance_dashboard_system.repository.TransactionRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import com.zorvyn.finance_dashboard_system.request.TransactionRequest;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Implementation of the Transaction Service.
 * Centralizes business logic for financial record keeping, including:
 * <ul>
 *   <li>Atomic transaction processing via {@link org.springframework.transaction.annotation.Transactional}.</li>
 *   <li>Idempotency checks to prevent duplicate financial entries.</li>
 *   <li>Precise currency calculations using {@link java.math.BigDecimal}.</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionService implements ITransactionService{
    private final TransactionRepository transactionRepository;
    private final UserRepository userRepository;
    private final CategoryRepository categoryRepository;

    /**
     * Records a new financial transaction.
     * <p>
     * <b>Selection Detail:</b> Implements Idempotency. Before saving, it verifies the
     * {@code requestId} against existing records to prevent "Double Charging"
     * during network retries.
     *
     * @param transactionDto Data containing amount, type, and category.
     * @throws DuplicateTransactionException if the requestId has already been processed.
     * @throws UserNotFoundException if the provided email does not exist.
     */
    @Override
    @Transactional
    public void addTransaction(TransactionRequest transactionDto) {
        try {
            if (transactionRepository.existsByIdempotencyKey(transactionDto.requestId())) {
                log.warn("Duplicate transaction blocked. RequestId: {}", transactionDto.requestId());
                throw new DuplicateTransactionException("Transaction with Request ID " +
                        transactionDto.requestId() + " has already been processed.");
            }
            User user = userRepository.findByEmailId(transactionDto.username())
                    .orElseThrow(() -> {
                        log.error("Transaction failed: User {} not found", transactionDto.username());
                        return new UserNotFoundException("User doesn't exist");
                    });
            Category category = categoryRepository
                    .findByName(transactionDto.category())
                    .orElseThrow(() -> {
                        log.error("Transaction failed: Category {} not found", transactionDto.category());
                        return new CategoryNotFoundException("Category with name '" + transactionDto.category() + "' does not exist.");
                    });
            Transaction transaction = TransactionRequest.toEntity(transactionDto);
            transaction.setUser(user);
            transaction.setIdentifierName(UUID.randomUUID().toString());
            category.addTransaction(transaction);
            transactionRepository.save(transaction);
            log.info("Transaction saved successfully. ID: {}, Amount: {}",
                    transaction.getIdentifierName(), transaction.getAmount());
        }
        catch (DataIntegrityViolationException ex){
            log.error("Database integrity violation for RequestId: {}", transactionDto.requestId());
            throw new DuplicateTransactionException("Transaction already processed.");
        }

    }

    /**
     * Updates an existing transaction's details.
     * <p>
     * <b>Selection Detail:</b> Uses UUID-based identifierName to locate the record,
     * ensuring the internal database ID is never exposed to the client.
     *
     * @param identifier The unique UUID string of the transaction.
     * @param transactionDto The updated data (Amount, Description, etc.).
     */
    @Override
    public void updateTransaction(String identifier, TransactionRequest transactionDto) {
        Transaction transaction = transactionRepository.findByIdentifierName(identifier).orElseThrow(
                () -> new TransactionNotFoundException("User doesn't exist: " + transactionDto.username())
        );

        User user = userRepository.findByEmailId(transactionDto.username())
                .orElseThrow(
                        () -> new UserNotFoundException("User doesn't exist: " + transactionDto.username())
                );
        Category category = categoryRepository
                .findByName(transactionDto.category())
                .orElseThrow(
                        () -> new CategoryNotFoundException("Category doesn't exit by " + transactionDto.category())
                );

        transaction.setAmount(transactionDto.amount());
        transaction.setDescription(transactionDto.description());
        transaction.setType(transactionDto.type());

        transaction.setUser(user);
        category.addTransaction(transaction);
        transactionRepository.save(transaction);

    }

    /**
     * Calculates all-time total income for a user.
     */
    @Override
    public BigDecimal getTotalIncome(String username) {
        Long id = getUserId(username);
        return transactionRepository
                .sumByUserIdAndType(id, TransactionType.INCOME);
    }

    /**
     * Calculates all-time total expenses for a user.
     */
    @Override
    public BigDecimal getTotalExpenses(String username) {
        Long id = getUserId(username);
        return transactionRepository
                .sumByUserIdAndType(id, TransactionType.EXPENSE);
    }

    /**
     * Calculates the all-time net balance (Income - Expenses).
     * Handles null-safety to prevent NullPointerExceptions on new accounts.
     */
    @Override
    public BigDecimal getNetBalance(String username) {
        BigDecimal income = getTotalIncome(username);
        BigDecimal expenses = getTotalExpenses(username);
        return (income != null ? income : BigDecimal.ZERO)
                .subtract(expenses != null ? expenses : BigDecimal.ZERO);
    }

    /**
      * Retrieves paginated transactions
     */
    @Override
    public Page<TransactionDto> getTranscations(int pageNo, int pageSize, String sortByField, String sortDirection) {
        Sort sort = sortDirection.toUpperCase().equals(Sort.Direction.DESC.name()) ? Sort.by(sortByField).descending():
                Sort.by(sortByField).ascending();
        Pageable pageable = PageRequest.of(pageNo,pageSize,sort);
        Page<Transaction> userPage = transactionRepository.findAll(pageable);
        return userPage.map(TransactionDto::toDto);
    }

    /**
     * Retrieves paginated transactions for the specific authenticated user.
     * Enforces 'User Data Isolation' security pattern.
     */
    @Override
    public Page<TransactionDto> getUserTransactions(String username, int pageNo, int pageSize, String sortByField, String sortDirection) {
        Long userId = getUserId(username); // Resolved from Security Context
        Sort sort = sortDirection.toUpperCase().equals(Sort.Direction.DESC.name()) ? Sort.by(sortByField).descending():
                Sort.by(sortByField).ascending();
        Pageable pageable = PageRequest.of(pageNo, pageSize,sort);
        return transactionRepository.findTransactionByUserId(userId, pageable)
                .map(TransactionDto::toDto);
    }

    /**
     * Helper method to resolve internal Database ID from username.
     * Reduces redundant code across service methods.
     */
    private Long getUserId(String username) {
        return userRepository.findByEmailId(username)
                .map(User::getId)
                .orElseThrow(() -> new UserNotFoundException("User doesn't exist: " + username));
    }




    /**
     * Retrieves the most recent single transaction for a user.
     *
     * @param username The authenticated user's email.
     * @return TransactionDto representing the user's data.
     */
    @Override
    public TransactionDto getTranscation(String username,String identifier) {
//        Long id = getUserId(username);
        Transaction transaction = transactionRepository.findByUserEmailId(username,identifier).orElseThrow(
                () -> new TransactionNotFoundException("Transaction doesn't exist by " + username)
        );
        return TransactionDto.toDto(transaction);
    }
}
