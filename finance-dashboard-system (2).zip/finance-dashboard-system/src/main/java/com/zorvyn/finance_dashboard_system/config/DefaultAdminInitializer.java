package com.zorvyn.finance_dashboard_system.config;


import com.zorvyn.finance_dashboard_system.entity.Role;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.enums.RoleType;
import com.zorvyn.finance_dashboard_system.repository.RoleRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * System Bootstrapper for Identity and Access Management.
 * Ensures the system has a 'Root' administrative user and the
 * necessary {@link Role} structure upon the first application startup.
 *
 * <p><b>Selection Detail:</b>
 * Uses {@link Transactional} to ensure that the Role creation and
 * Admin assignment are atomic, preventing a "Partial-Admin" state
 * if the database connection flickers during startup.</p>
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DefaultAdminInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    /**
     * Executes the bootstrap logic immediately after the ApplicationContext is loaded.
     *
     * @param args Command line arguments.
     * @throws Exception If a critical database error occurs during initialization.
     */
    @Transactional
    @Override
    public void run(String... args) throws Exception {
        log.info("System Bootstrap: Checking for administrative authorities...");

        // Ensure ROLE_ADMIN exists in the registry
        String adminRoleName = "ROLE_" + RoleType.ADMIN;
        Role adminRole = roleRepository
                .findByName(adminRoleName)
                .orElseGet(() -> {
                    log.info("System Bootstrap: Creating missing authority - {}", adminRoleName);
                    return roleRepository.save(new Role(adminRoleName));
                });

        // Seed the Default System Administrator
        String adminEmail = "admin@gmail.com";
        if (!userRepository.existsByEmailId(adminEmail)) {
            log.warn("System Bootstrap: No administrator found. Provisioning default 'Root' account.");

            User admin = User.builder()
                    .firstName("System")
                    .lastName("Admin")
                    .emailId(adminEmail)
                    .mobileNo("**********")
                    .password(passwordEncoder.encode("Admin@123"))
                    .build();

            // Use the Domain-Driven helper to link the role
            adminRole.assignRoleToUser(admin);
            userRepository.save(admin);

            log.info("System Bootstrap Success: Administrator provisioned. Username: {}", adminEmail);
        } else {
            log.debug("System Bootstrap: Administrative account verified.");
        }
    }
}
