package com.zorvyn.finance_dashboard_system.service;

import com.zorvyn.finance_dashboard_system.dto.UserDto;
import com.zorvyn.finance_dashboard_system.entity.Role;
import com.zorvyn.finance_dashboard_system.entity.User;
import com.zorvyn.finance_dashboard_system.enums.RoleType;
import com.zorvyn.finance_dashboard_system.exceptions.DuplicateEmailException;
import com.zorvyn.finance_dashboard_system.exceptions.DuplicateMobileNumberException;
import com.zorvyn.finance_dashboard_system.exceptions.UserAlreadyExistsException;
import com.zorvyn.finance_dashboard_system.exceptions.UserNotFoundException;
import com.zorvyn.finance_dashboard_system.repository.RoleRepository;
import com.zorvyn.finance_dashboard_system.repository.UserRepository;
import com.zorvyn.finance_dashboard_system.request.UserRequest;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Implementation of User Management and Security operations.
 * Handles the lifecycle of {@link User} entities, including:
 * <ul>
 *   <li>Secure registration with Bcrypt password encoding.</li>
 *   <li>Granular Role assignment for Access Control.</li>
 *   <li>Identity verification for the Authentication Manager.</li>
 * </ul>
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class UserService implements IUserService, UserDetailsService {


   private final UserRepository userRepository;
   private final RoleRepository roleRepository;
   private final PasswordEncoder encoder;


    /**
     * Registers a new user into the system.
     * <p><b>Selection Detail:</b> Implements 'Secure-by-Default' by encoding
     * passwords before persistence and validating email uniqueness.</p>
     *
     * @param userDto Data transfer object containing user profile and credentials.
     * @throws UserAlreadyExistsException if the email is already registered.
     */
    @Override
    @Transactional
    public void addUser(UserRequest userDto) {
        log.info("Attempting to register new user with email: {}", userDto.emailId());
        if(userRepository.existsByEmailId(userDto.emailId())){
            log.warn("Registration failed: Email {} is already in use.", userDto.emailId());
            throw new UserAlreadyExistsException("The user already exists by " + userDto.emailId());
        }
        if(userRepository.existsByMobileNo(userDto.mobileNo())) {
            log.warn("Registration failed: Mobile number {} is already in use.", userDto.mobileNo());
            throw new UserAlreadyExistsException("The user already exists by " + userDto.mobileNo());
        }
        User entity = UserRequest.toEntity(userDto);
        entity.setPassword(encoder.encode(userDto.password()));
        Role role = roleRepository
                .findByName("ROLE_USER")
                .orElseGet(() -> roleRepository.save(new Role("ROLE_USER")));
        role.assignRoleToUser(entity);
        userRepository.save(entity);
        log.info("User registered successfully. Assigned ID: {}", entity.getId());
    }


    /**
     * Placeholder for ID-based updates. Currently disabled to enforce
     * business-logic updates via email identifiers.
     */
    @Override
    public void updateUser(Long id, UserDto userDto) {
        log.error("Unsupported operation: ID-based update called for ID {}", id);
        throw new UnsupportedOperationException("Operation is not supported. Use email-based update.");
    }

    /**
     * Removes a user from the system based on their email identifier.
     * <p><b>Selection Detail:</b> Cascading rules in the Entity will ensure
     * associated roles and transactions are handled per the defined policy.</p>
     *
     * @param username The email of the user to be deleted.
     */
    @Override
    @Transactional
    public void deleteUser(String username) {
        log.warn("PERMANENT DELETE request for user: {}", username);
        if (!userRepository.existsByEmailId(username)) {
            log.error("Delete failed: User {} not found.", username);
            throw new UserNotFoundException("User not found");
        }
        userRepository.deleteByEmailId(username);
        log.info("User {} and associated data removed from system.", username);
    }

    /**
     * Updates an existing user's profile and credentials.
     * <p><b>Security Note:</b> Re-encodes the password using BCrypt before persistence
     * to ensure the security principal remains valid.</p>
     *
     * @param username The unique email identifier of the user to update.
     * @param userDto  The updated profile data and new password.
     */
    @Override
    public void updateUser(String username, UserRequest userDto) {
        log.info("Request to update profile for user: {}", username);
        User user = userRepository.findByEmailId(username)
                .orElseThrow(() -> {
                    log.error("Update failed: User with email {} does not exist.", username);
                    return  new UserNotFoundException("User doesn't exit by " + username);
                });
        if (userDto.firstName() != null) user.setFirstName(userDto.firstName());
        if (userDto.lastName() != null) user.setLastName(userDto.lastName());
        //(Note: This changes the login username!)
        if (!user.getEmailId().equals(userDto.emailId())) {
            if (userRepository.existsByEmailId(userDto.emailId())) {
                log.error("Update failed: New User with email {} already exist.", username);
                throw new DuplicateEmailException("New email is already registered");
            }
            user.setEmailId(userDto.emailId());
        }
        if (!user.getMobileNo().equals(userDto.mobileNo())) {
            if (userRepository.existsByMobileNo(userDto.mobileNo())) {
                log.error("Update failed: New User with mobile {} already exist.", userDto.mobileNo());
                throw new DuplicateMobileNumberException("This mobile number is already registered to another user.");
            }
            user.setMobileNo(userDto.mobileNo());

        }
        if (userDto.password() != null && !userDto.password().isBlank()) {
            user.setPassword(encoder.encode(userDto.password()));
        }
        userRepository.save(user);
        log.info("User profile for {} updated successfully.", username);
    }

    /**
     * Retrieves a paginated and sorted list of all system users.
     * <p><b>Selection Detail:</b> Leverages Spring Data {@link Pageable} to
     * prevent memory exhaustion when dealing with large user bases.</p>
     *
     * @return A {@link Page} of User DTOs mapped from the persistent entities.
     */
    @Override
    public Page<UserDto> getUsers(int pageNo, int pageSize, String sortByField, String sortDirection) {
        log.info("Fetching paginated user list. Page: {}, Size: {}, Sort: {}", pageNo, pageSize, sortByField);
        Sort sort = sortDirection.toUpperCase().equals(Sort.Direction.DESC.name()) ? Sort.by(sortByField).descending():
                Sort.by(sortByField).ascending();
        Pageable pageable = PageRequest.of(pageNo,pageSize,sort);
        Page<User> userPage = userRepository.findAll(pageable);
        return userPage.map(UserDto::toDto);
    }

    /**
     * Resolves a user profile by their email.
     * Used for profile management and internal security checks.
     */
    @Override
    @Transactional()
    public UserDto getUser(String username) {
        log.debug("Fetching profile details for: {}", username);
        return userRepository
                .findByEmailId(username)
                .map(UserDto::toDto)
                .orElseThrow(() -> {
                    log.warn("Profile fetch failed: User {} does not exist.", username);
                    return new UserNotFoundException("User not found");
                });
    }

    /**
     * Locates the user based on the email identifier for the authentication provider.
     * <p><b>Selection Detail:</b> Directly integrates with Spring Security's
     * {@link org.springframework.security.authentication.dao.DaoAuthenticationProvider}.
     * Returns the {@link User} entity which implements {@link UserDetails},
     * including its {@link org.springframework.security.core.GrantedAuthority} set.</p>
     *
     * @param email The user's primary email address.
     * @return UserDetails containing the principal's credentials and authorities.
     * @throws UsernameNotFoundException if the email is not registered in the system.
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        log.debug("Security: Attempting to load UserDetails for email: {}", email);
        return userRepository.findByEmailId(email)
                .orElseThrow(() -> {
                    log.warn("Authentication failed: User with email {} not found.", email);
                    return new UsernameNotFoundException("User not found with email: " + email);
                });
    }
}
